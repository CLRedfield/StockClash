/* @ds-bundle: {"format":3,"namespace":"StockClashDesignSystem_2f48a1","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"NumberStepper","sourcePath":"components/forms/NumberStepper.jsx"},{"name":"SegmentedControl","sourcePath":"components/forms/SegmentedControl.jsx"},{"name":"SourceChip","sourcePath":"components/forms/SourceChip.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Countdown","sourcePath":"components/trading/Countdown.jsx"},{"name":"LeaderboardRow","sourcePath":"components/trading/LeaderboardRow.jsx"},{"name":"PriceTag","sourcePath":"components/trading/PriceTag.jsx"},{"name":"PropCard","sourcePath":"components/trading/PropCard.jsx"},{"name":"SeatTile","sourcePath":"components/trading/SeatTile.jsx"},{"name":"StatTile","sourcePath":"components/trading/StatTile.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"f96edb182fe2","components/core/Button.jsx":"6d2eda6d364b","components/core/Card.jsx":"7f8aa1050fd0","components/core/IconButton.jsx":"23778c81f5d5","components/feedback/Dialog.jsx":"8a0f6516dea8","components/feedback/Toast.jsx":"0d8ed5054834","components/forms/NumberStepper.jsx":"831991bc8cc4","components/forms/SegmentedControl.jsx":"8a98b8475127","components/forms/SourceChip.jsx":"9f5eda16243e","components/forms/Switch.jsx":"d3f4138491ac","components/trading/Countdown.jsx":"867d5686ea6b","components/trading/LeaderboardRow.jsx":"ab1a7ea732aa","components/trading/PriceTag.jsx":"cdb135297446","components/trading/PropCard.jsx":"4fbd8e606d9f","components/trading/SeatTile.jsx":"759d834863a6","components/trading/StatTile.jsx":"ca2ab6d07617","ui_kits/stockclash/App.jsx":"806459ce6b38","ui_kits/stockclash/Chart.jsx":"d26a65121e56","ui_kits/stockclash/Home.jsx":"45fe84f99faa","ui_kits/stockclash/Room.jsx":"09d180b623fe","ui_kits/stockclash/Settlement.jsx":"a45d6f3f947f","ui_kits/stockclash/Trading.jsx":"b8177f20c984","ui_kits/stockclash/lib.jsx":"99115520b2ac"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.StockClashDesignSystem_2f48a1 = window.StockClashDesignSystem_2f48a1 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Compact label pill. Tones cover status + the four market hues.
 */
function Badge({
  children,
  tone = "neutral",
  solid = false,
  dot = false,
  style = {},
  ...rest
}) {
  const map = {
    neutral: ["var(--slate-600)", "var(--slate-100)", "var(--slate-200)"],
    accent: ["var(--gold-700)", "var(--gold-50)", "var(--gold-200)"],
    up: ["var(--price-up)", "var(--price-up-soft)", "var(--price-up-border)"],
    down: ["var(--price-down)", "var(--price-down-soft)", "var(--price-down-border)"],
    info: ["var(--info-500)", "var(--info-50)", "color-mix(in srgb, var(--info-500) 22%, transparent)"],
    warn: ["var(--warn-500)", "var(--warn-50)", "color-mix(in srgb, var(--warn-500) 26%, transparent)"],
    cn: ["var(--mkt-cn)", "color-mix(in srgb, var(--mkt-cn) 10%, white)", "color-mix(in srgb, var(--mkt-cn) 28%, transparent)"],
    hk: ["var(--mkt-hk)", "color-mix(in srgb, var(--mkt-hk) 10%, white)", "color-mix(in srgb, var(--mkt-hk) 28%, transparent)"],
    us: ["var(--mkt-us)", "color-mix(in srgb, var(--mkt-us) 10%, white)", "color-mix(in srgb, var(--mkt-us) 28%, transparent)"],
    crypto: ["var(--mkt-crypto)", "color-mix(in srgb, var(--mkt-crypto) 12%, white)", "color-mix(in srgb, var(--mkt-crypto) 30%, transparent)"]
  };
  const [fg, bg, bd] = map[tone] || map.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "5px",
      height: "22px",
      padding: "0 9px",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-tight)",
      lineHeight: 1,
      whiteSpace: "nowrap",
      color: solid ? "#fff" : fg,
      background: solid ? fg : bg,
      border: `1px solid ${solid ? "transparent" : bd}`,
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 99,
      background: solid ? "#fff" : fg
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * StockClash primary button.
 * Variants: primary (gold), secondary (outline), ghost, danger, up, down.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  block = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      height: "var(--control-sm)",
      padding: "0 12px",
      fontSize: "var(--text-sm)",
      gap: "6px",
      radius: "var(--radius-sm)"
    },
    md: {
      height: "var(--control-md)",
      padding: "0 18px",
      fontSize: "var(--text-base)",
      gap: "8px",
      radius: "var(--radius-md)"
    },
    lg: {
      height: "var(--control-lg)",
      padding: "0 26px",
      fontSize: "var(--text-md)",
      gap: "10px",
      radius: "var(--radius-md)"
    }
  };
  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--on-accent)",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-xs)"
    },
    secondary: {
      background: "var(--surface-card)",
      color: "var(--text-primary)",
      border: "1px solid var(--border-strong)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-secondary)",
      border: "1px solid transparent"
    },
    danger: {
      background: "var(--danger-500)",
      color: "#fff",
      border: "1px solid transparent"
    },
    up: {
      background: "var(--price-up)",
      color: "#fff",
      border: "1px solid transparent"
    },
    down: {
      background: "var(--price-down)",
      color: "#fff",
      border: "1px solid transparent"
    }
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    style: {
      display: block ? "flex" : "inline-flex",
      width: block ? "100%" : "auto",
      alignItems: "center",
      justifyContent: "center",
      gap: s.gap,
      height: s.height,
      padding: s.padding,
      fontSize: s.fontSize,
      fontFamily: "var(--font-sans)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-tight)",
      lineHeight: 1,
      borderRadius: s.radius,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "transform var(--dur-fast) var(--ease-out), filter var(--dur-fast) var(--ease-out), background var(--dur-fast) var(--ease-out)",
      whiteSpace: "nowrap",
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = "translateY(1px) scale(0.985)";
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = "";
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "";
      e.currentTarget.style.filter = "";
    },
    onMouseEnter: e => {
      if (!disabled) e.currentTarget.style.filter = "brightness(0.96)";
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Surface card — hairline border leads, shadow is a soft lift.
 * `tone="raised"` adds the shadow; `tone="sunken"` insets it.
 */
function Card({
  children,
  tone = "flat",
  padding = "20px",
  header = null,
  footer = null,
  glow = false,
  style = {},
  ...rest
}) {
  const tones = {
    flat: {
      background: "var(--surface-card)",
      boxShadow: "var(--shadow-card)"
    },
    raised: {
      background: "var(--surface-card)",
      boxShadow: "var(--shadow-md)"
    },
    sunken: {
      background: "var(--surface-inset)",
      boxShadow: "none"
    }
  };
  const t = tones[tone] || tones.flat;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderRadius: "var(--radius-lg)",
      border: "1px solid var(--border-subtle)",
      overflow: "hidden",
      ...t,
      ...(glow ? {
        boxShadow: "var(--glow-gold)",
        borderColor: "var(--accent-soft-border)"
      } : null),
      ...style
    }
  }, rest), header && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 20px",
      borderBottom: "1px solid var(--border-subtle)",
      fontFamily: "var(--font-display)",
      fontWeight: "var(--weight-semibold)",
      fontSize: "var(--text-md)",
      color: "var(--text-primary)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      padding
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 20px",
      borderTop: "1px solid var(--border-subtle)",
      background: "var(--surface-inset)"
    }
  }, footer));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Square icon-only button. Pass a Lucide <i data-lucide> node or any glyph as children.
 */
function IconButton({
  children,
  variant = "ghost",
  size = "md",
  disabled = false,
  label,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: 32,
    md: 40,
    lg: 48
  };
  const dim = sizes[size] || sizes.md;
  const variants = {
    ghost: {
      background: "transparent",
      color: "var(--text-secondary)",
      border: "1px solid transparent"
    },
    outline: {
      background: "var(--surface-card)",
      color: "var(--text-primary)",
      border: "1px solid var(--border-default)"
    },
    soft: {
      background: "var(--surface-sunken)",
      color: "var(--text-primary)",
      border: "1px solid transparent"
    },
    accent: {
      background: "var(--accent-soft)",
      color: "var(--accent-press)",
      border: "1px solid var(--accent-soft-border)"
    }
  };
  const v = variants[variant] || variants.ghost;
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": label,
    title: label,
    disabled: disabled,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: dim,
      height: dim,
      borderRadius: "var(--radius-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "background var(--dur-fast) var(--ease-out), filter var(--dur-fast) var(--ease-out)",
      ...v,
      ...style
    },
    onMouseEnter: e => {
      if (!disabled && variant === "ghost") e.currentTarget.style.background = "var(--surface-sunken)";
    },
    onMouseLeave: e => {
      if (variant === "ghost") e.currentTarget.style.background = "transparent";
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Centered modal dialog with scrim. Use for 贷款/还款 confirm, 结算, 破产, 被踢提示.
 */
function Dialog({
  open = true,
  title,
  children,
  footer = null,
  onClose,
  tone = "default",
  width = 420,
  style = {},
  ...rest
}) {
  if (!open) return null;
  const accentBar = {
    default: "var(--accent)",
    danger: "var(--price-down)",
    up: "var(--price-up)"
  }[tone] || "var(--accent)";
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: "var(--z-modal)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 20,
      background: "color-mix(in srgb, var(--slate-950) 38%, transparent)",
      backdropFilter: "var(--blur-overlay)"
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    onClick: e => e.stopPropagation(),
    role: "dialog",
    style: {
      width,
      maxWidth: "100%",
      background: "var(--surface-card)",
      borderRadius: "var(--radius-xl)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-lg)",
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: accentBar
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 22px"
    }
  }, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-lg)",
      marginBottom: 10
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-base)",
      color: "var(--text-secondary)",
      lineHeight: 1.6
    }
  }, children)), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 10,
      padding: "14px 22px",
      borderTop: "1px solid var(--border-subtle)",
      background: "var(--surface-inset)"
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  info: ["var(--info-500)", "var(--info-50)"],
  up: ["var(--price-up)", "var(--price-up-soft)"],
  down: ["var(--price-down)", "var(--price-down-soft)"],
  warn: ["var(--warn-500)", "var(--warn-50)"],
  accent: ["var(--accent-press)", "var(--accent-soft)"]
};

/**
 * Toast / fx notice — 成交飘字, 爆仓, 道具登场, 喊话. Self-contained pill.
 */
function Toast({
  children,
  tone = "info",
  icon = null,
  title,
  style = {},
  ...rest
}) {
  const [color, bg] = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      padding: "10px 14px",
      minWidth: 200,
      maxWidth: 360,
      borderRadius: "var(--radius-md)",
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-lg)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "var(--radius-sm)",
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: bg,
      color
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-primary)"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)",
      lineHeight: 1.4
    }
  }, children)));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/NumberStepper.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Number stepper — quantity / amount input for the trade panel.
 * Monospace tabular value with − / + steppers and an optional unit suffix.
 */
function NumberStepper({
  value = 0,
  step = 1,
  min = 0,
  max = Infinity,
  unit = "",
  onChange,
  style = {},
  ...rest
}) {
  const set = v => onChange && onChange(Math.max(min, Math.min(max, v)));
  const btn = {
    width: 38,
    height: 38,
    flexShrink: 0,
    border: "none",
    cursor: "pointer",
    background: "var(--surface-sunken)",
    color: "var(--text-secondary)",
    fontSize: 18,
    fontWeight: 600,
    lineHeight: 1,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      alignItems: "stretch",
      height: 40,
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      overflow: "hidden",
      background: "var(--surface-card)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("button", {
    style: {
      ...btn,
      borderRight: "1px solid var(--border-subtle)"
    },
    onClick: () => set(value - step)
  }, "\u2212"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 72,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 4,
      padding: "0 10px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-md)",
      fontWeight: "var(--weight-semibold)",
      fontVariantNumeric: "tabular-nums lining-nums",
      color: "var(--text-primary)"
    }
  }, value.toLocaleString("en-US"), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)",
      fontFamily: "var(--font-sans)"
    }
  }, unit)), /*#__PURE__*/React.createElement("button", {
    style: {
      ...btn,
      borderLeft: "1px solid var(--border-subtle)"
    },
    onClick: () => set(value + step)
  }, "+"));
}
Object.assign(__ds_scope, { NumberStepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/NumberStepper.jsx", error: String((e && e.message) || e) }); }

// components/forms/SegmentedControl.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Segmented control — single-select pill row.
 * Used for 档位 (闪电/标准/长局), quick-amount (25/50/100%), color convention, etc.
 */
function SegmentedControl({
  options = [],
  value,
  onChange,
  size = "md",
  style = {},
  ...rest
}) {
  const heights = {
    sm: 30,
    md: 38,
    lg: 46
  };
  const h = heights[size] || heights.md;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: "inline-flex",
      padding: 3,
      gap: 2,
      background: "var(--surface-sunken)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)",
      ...style
    }
  }, rest), options.map(opt => {
    const o = typeof opt === "string" ? {
      value: opt,
      label: opt
    } : opt;
    const active = o.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: o.value,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(o.value),
      style: {
        height: h - 6,
        padding: "0 14px",
        border: "none",
        borderRadius: "var(--radius-sm)",
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        fontWeight: "var(--weight-semibold)",
        letterSpacing: "var(--tracking-tight)",
        color: active ? "var(--text-primary)" : "var(--text-secondary)",
        background: active ? "var(--surface-card)" : "transparent",
        boxShadow: active ? "var(--shadow-sm)" : "none",
        transition: "all var(--dur-fast) var(--ease-out)",
        whiteSpace: "nowrap",
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, o.icon, o.label, o.star && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--accent)"
      }
    }, "\u2605"));
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/forms/SourceChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const HUES = {
  cn: "var(--mkt-cn)",
  hk: "var(--mkt-hk)",
  us: "var(--mkt-us)",
  crypto: "var(--mkt-crypto)"
};

/**
 * Toggleable market-source chip (K线来源 multiselect). Selected = filled hue tint + check.
 */
function SourceChip({
  market = "cn",
  label,
  checked = false,
  disabled = false,
  onChange,
  style = {},
  ...rest
}) {
  const hue = HUES[market] || "var(--slate-500)";
  return /*#__PURE__*/React.createElement("button", _extends({
    role: "checkbox",
    "aria-checked": checked,
    disabled: disabled,
    onClick: () => onChange && onChange(!checked),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      height: 38,
      padding: "0 14px 0 12px",
      borderRadius: "var(--radius-pill)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-tight)",
      color: checked ? hue : "var(--text-secondary)",
      background: checked ? `color-mix(in srgb, ${hue} 10%, white)` : "var(--surface-card)",
      border: `1px solid ${checked ? `color-mix(in srgb, ${hue} 38%, transparent)` : "var(--border-default)"}`,
      transition: "all var(--dur-fast) var(--ease-out)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: "var(--radius-xs)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: checked ? hue : "transparent",
      border: `1.5px solid ${checked ? hue : "var(--border-strong)"}`,
      transition: "all var(--dur-fast) var(--ease-out)"
    }
  }, checked && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6L9 17l-5-5"
  }))), label);
}
Object.assign(__ds_scope, { SourceChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SourceChip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Toggle switch for boolean room rules (盲盒 / 道具模式 / 自由换座).
 */
function Switch({
  checked = false,
  disabled = false,
  onChange,
  size = "md",
  style = {},
  ...rest
}) {
  const dims = {
    sm: [36, 20, 16],
    md: [44, 24, 20]
  };
  const [w, hh, knob] = dims[size] || dims.md;
  return /*#__PURE__*/React.createElement("button", _extends({
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: () => onChange && onChange(!checked),
    style: {
      position: "relative",
      width: w,
      height: hh,
      flexShrink: 0,
      borderRadius: "var(--radius-pill)",
      border: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      padding: 0,
      background: checked ? "var(--accent)" : "var(--slate-300)",
      transition: "background var(--dur-base) var(--ease-out)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: (hh - knob) / 2,
      left: checked ? w - knob - (hh - knob) / 2 : (hh - knob) / 2,
      width: knob,
      height: knob,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "var(--shadow-sm)",
      transition: "left var(--dur-base) var(--ease-out)"
    }
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/trading/Countdown.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Match countdown — mm:ss monospace with a thin progress track.
 * Turns to the warn/danger hue under the threshold seconds.
 */
function Countdown({
  remaining = 0,
  total = 240,
  size = "md",
  style = {},
  ...rest
}) {
  const m = Math.floor(Math.max(0, remaining) / 60);
  const s = Math.max(0, remaining) % 60;
  const txt = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  const frac = total ? Math.max(0, Math.min(1, remaining / total)) : 0;
  const danger = remaining <= 15;
  const warn = remaining <= 30 && !danger;
  const color = danger ? "var(--price-down)" : warn ? "var(--warn-500)" : "var(--text-primary)";
  const fontSizes = {
    sm: "var(--text-lg)",
    md: "var(--text-2xl)",
    lg: "var(--text-4xl)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: "2.2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "13",
    r: "8"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 9v4l2.5 2.5M9 2h6"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: fontSizes[size] || fontSizes.md,
      fontWeight: "var(--weight-bold)",
      fontVariantNumeric: "tabular-nums",
      letterSpacing: "var(--tracking-tight)",
      color,
      lineHeight: 1,
      animation: danger ? "sc-pulse 1s var(--ease-in-out) infinite" : "none"
    }
  }, txt)), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 4,
      borderRadius: 99,
      background: "var(--surface-sunken)",
      overflow: "hidden",
      width: "100%",
      minWidth: 90
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      width: `${frac * 100}%`,
      background: color,
      borderRadius: 99,
      transition: "width 1s linear"
    }
  })), /*#__PURE__*/React.createElement("style", null, `@keyframes sc-pulse{0%,100%{opacity:1}50%{opacity:0.45}}`));
}
Object.assign(__ds_scope, { Countdown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/Countdown.jsx", error: String((e && e.message) || e) }); }

// components/trading/LeaderboardRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const AI_TONE = {
  easy: "var(--slate-400)",
  normal: "var(--info-500)",
  hard: "var(--mkt-us)"
};

/**
 * Live leaderboard row — rank, player, net worth, trend.
 * `you` highlights the current player; `ai` shows a difficulty chip.
 */
function LeaderboardRow({
  rank,
  name,
  net,
  deltaPct = 0,
  you = false,
  ai = null,
  broke = false,
  style = {},
  ...rest
}) {
  const dir = deltaPct > 0 ? "up" : deltaPct < 0 ? "down" : "flat";
  const dColor = dir === "up" ? "var(--price-up)" : dir === "down" ? "var(--price-down)" : "var(--price-flat)";
  const medal = rank === 1 ? "var(--gold-500)" : rank === 2 ? "var(--slate-400)" : rank === 3 ? "#c08a4a" : "var(--slate-300)";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      height: 48,
      padding: "0 12px",
      borderRadius: "var(--radius-md)",
      background: you ? "var(--accent-soft)" : "transparent",
      border: `1px solid ${you ? "var(--accent-soft-border)" : "transparent"}`,
      opacity: broke ? 0.55 : 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      textAlign: "center",
      flexShrink: 0,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-md)",
      fontWeight: "var(--weight-bold)",
      color: rank <= 3 ? medal : "var(--text-tertiary)"
    }
  }, rank), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "50%",
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: you ? "var(--accent)" : "var(--surface-sunken)",
      color: you ? "var(--on-accent)" : "var(--text-secondary)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-bold)",
      fontFamily: "var(--font-display)"
    }
  }, String(name || "").slice(0, 1)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-primary)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, name, you && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent-press)"
    }
  }, " \xB7 \u4F60")), ai && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--weight-semibold)",
      padding: "1px 6px",
      borderRadius: "var(--radius-pill)",
      color: AI_TONE[ai] || AI_TONE.normal,
      background: `color-mix(in srgb, ${AI_TONE[ai] || AI_TONE.normal} 12%, white)`
    }
  }, "AI\xB7", ai === "easy" ? "简" : ai === "hard" ? "难" : "普"), broke && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--price-down)",
      fontWeight: 600
    }
  }, "\u7834\u4EA7")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-bold)",
      fontVariantNumeric: "tabular-nums lining-nums",
      color: "var(--text-primary)",
      lineHeight: 1.2
    }
  }, net), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--weight-semibold)",
      color: dColor,
      lineHeight: 1.2
    }
  }, deltaPct > 0 ? "+" : "", deltaPct.toFixed(1), "%")));
}
Object.assign(__ds_scope, { LeaderboardRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/LeaderboardRow.jsx", error: String((e && e.message) || e) }); }

// components/trading/PriceTag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Price + change display. Green up / red down (international convention).
 * `direction` overrides auto-detection from `change`.
 */
function PriceTag({
  price,
  change = 0,
  changePct,
  direction,
  size = "md",
  showArrow = true,
  style = {},
  ...rest
}) {
  const dir = direction || (change > 0 ? "up" : change < 0 ? "down" : "flat");
  const color = dir === "up" ? "var(--price-up)" : dir === "down" ? "var(--price-down)" : "var(--price-flat)";
  const arrow = dir === "up" ? "▲" : dir === "down" ? "▼" : "—";
  const sizes = {
    sm: {
      price: "var(--text-md)",
      meta: "var(--text-2xs)",
      gap: 6
    },
    md: {
      price: "var(--text-2xl)",
      meta: "var(--text-sm)",
      gap: 8
    },
    lg: {
      price: "var(--text-4xl)",
      meta: "var(--text-md)",
      gap: 10
    }
  };
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      alignItems: "baseline",
      gap: s.gap,
      fontFamily: "var(--font-mono)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: s.price,
      fontWeight: "var(--weight-bold)",
      color,
      fontVariantNumeric: "tabular-nums lining-nums",
      letterSpacing: "var(--tracking-tight)",
      lineHeight: 1
    }
  }, typeof price === "number" ? price.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }) : price), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 3,
      fontSize: s.meta,
      fontWeight: "var(--weight-semibold)",
      color,
      fontVariantNumeric: "tabular-nums"
    }
  }, showArrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "0.85em"
    }
  }, arrow), changePct != null ? `${changePct > 0 ? "+" : ""}${changePct.toFixed(2)}%` : `${change > 0 ? "+" : ""}${change}`));
}
Object.assign(__ds_scope, { PriceTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/PriceTag.jsx", error: String((e && e.message) || e) }); }

// components/trading/PropCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CAT = {
  buff: ["增益", "var(--price-up)"],
  info: ["信息", "var(--info-500)"],
  pvp: ["搅局", "var(--price-down)"]
};

/**
 * Prop / item card (道具模式). Category-tinted, with icon, name, and effect line.
 * `compact` renders the slot-bar variant.
 */
function PropCard({
  name,
  desc,
  category = "buff",
  icon = null,
  count = 1,
  disabled = false,
  compact = false,
  onUse,
  style = {},
  ...rest
}) {
  const [catLabel, color] = CAT[category] || CAT.buff;
  if (compact) {
    return /*#__PURE__*/React.createElement("button", _extends({
      onClick: onUse,
      disabled: disabled,
      style: {
        position: "relative",
        width: 52,
        height: 52,
        flexShrink: 0,
        borderRadius: "var(--radius-md)",
        cursor: disabled ? "not-allowed" : "pointer",
        background: `color-mix(in srgb, ${color} 9%, white)`,
        border: `1px solid color-mix(in srgb, ${color} 32%, transparent)`,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        color,
        opacity: disabled ? 0.5 : 1,
        ...style
      },
      title: name
    }, rest), icon, count > 1 && /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        top: -6,
        right: -6,
        minWidth: 18,
        height: 18,
        padding: "0 4px",
        borderRadius: 99,
        background: color,
        color: "#fff",
        fontSize: 11,
        fontWeight: 700,
        fontFamily: "var(--font-mono)",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, count));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: 14,
      width: 180,
      borderRadius: "var(--radius-lg)",
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-card)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 38,
      borderRadius: "var(--radius-md)",
      background: `color-mix(in srgb, ${color} 12%, white)`,
      color,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, icon), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: 700,
      padding: "2px 8px",
      borderRadius: 99,
      color,
      background: `color-mix(in srgb, ${color} 10%, white)`,
      border: `1px solid color-mix(in srgb, ${color} 26%, transparent)`
    }
  }, catLabel)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-md)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-primary)",
      fontFamily: "var(--font-display)"
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)",
      lineHeight: 1.5,
      marginTop: 4
    }
  }, desc)), /*#__PURE__*/React.createElement("button", {
    onClick: onUse,
    disabled: disabled,
    style: {
      height: 32,
      border: "none",
      borderRadius: "var(--radius-sm)",
      cursor: disabled ? "not-allowed" : "pointer",
      background: color,
      color: "#fff",
      fontSize: "var(--text-sm)",
      fontWeight: 600,
      fontFamily: "var(--font-sans)",
      opacity: disabled ? 0.5 : 1
    }
  }, "\u4F7F\u7528", category === "pvp" ? " · 选目标" : ""));
}
Object.assign(__ds_scope, { PropCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/PropCard.jsx", error: String((e && e.message) || e) }); }

// components/trading/SeatTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const DIFF = {
  easy: ["简", "var(--slate-500)"],
  normal: ["普", "var(--info-500)"],
  hard: ["难", "var(--mkt-us)"]
};

/**
 * Room seat tile — a human player, an AI补位, or an empty seat.
 * Host controls (kick ✕ / AI difficulty cycle) are surfaced when `canEdit`.
 */
function SeatTile({
  seat,
  name,
  type = "empty",
  host = false,
  you = false,
  ai = "normal",
  canEdit = false,
  onKick,
  onCycleAi,
  onSwap,
  style = {},
  ...rest
}) {
  const empty = type === "empty";
  const isAi = type === "ai";
  const [glyph, aiColor] = DIFF[ai] || DIFF.normal;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center",
      gap: 11,
      height: 60,
      padding: "0 14px",
      borderRadius: "var(--radius-lg)",
      background: empty ? "var(--surface-inset)" : "var(--surface-card)",
      border: `1px ${empty ? "dashed" : "solid"} ${you ? "var(--accent)" : "var(--border-default)"}`,
      boxShadow: empty ? "none" : "var(--shadow-card)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      fontWeight: 700,
      color: "var(--text-tertiary)",
      width: 18,
      flexShrink: 0
    }
  }, "#", seat), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: "50%",
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: empty ? "transparent" : isAi ? `color-mix(in srgb, ${aiColor} 14%, white)` : you ? "var(--accent)" : "var(--surface-sunken)",
      border: empty ? "1.5px dashed var(--border-strong)" : "none",
      color: isAi ? aiColor : you ? "var(--on-accent)" : "var(--text-secondary)",
      fontSize: "var(--text-sm)",
      fontWeight: 700,
      fontFamily: "var(--font-display)"
    }
  }, empty ? "" : isAi ? "AI" : String(name || "").slice(0, 1)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-semibold)",
      color: empty ? "var(--text-tertiary)" : "var(--text-primary)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, empty ? "空位" : isAi ? "AI 补位" : name), host && /*#__PURE__*/React.createElement("span", {
    title: "\u623F\u4E3B",
    style: {
      color: "var(--gold-500)"
    }
  }, "\u265B"), you && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--accent-press)",
      fontWeight: 700
    }
  }, "\u4F60"))), isAi && /*#__PURE__*/React.createElement("button", {
    onClick: () => canEdit && onCycleAi && onCycleAi(),
    disabled: !canEdit,
    style: {
      height: 26,
      padding: "0 10px",
      borderRadius: "var(--radius-pill)",
      cursor: canEdit ? "pointer" : "default",
      border: `1px solid color-mix(in srgb, ${aiColor} 30%, transparent)`,
      background: `color-mix(in srgb, ${aiColor} 10%, white)`,
      color: aiColor,
      fontSize: "var(--text-2xs)",
      fontWeight: 700,
      fontFamily: "var(--font-sans)"
    }
  }, glyph), canEdit && !empty && !host && /*#__PURE__*/React.createElement("button", {
    onClick: onKick,
    "aria-label": "\u8E22\u4EBA",
    style: {
      width: 24,
      height: 24,
      borderRadius: "50%",
      border: "none",
      cursor: "pointer",
      background: "var(--surface-sunken)",
      color: "var(--text-tertiary)",
      fontSize: 13,
      lineHeight: 1
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { SeatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/SeatTile.jsx", error: String((e && e.message) || e) }); }

// components/trading/StatTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Labeled metric tile for the trade HUD — 现金 / 持仓 / 负债 / 净值.
 * `accent` tints the value (e.g. up/down for 净值 P&L, warn for 负债).
 */
function StatTile({
  label,
  value,
  sub,
  accent = "neutral",
  emphasis = false,
  style = {},
  ...rest
}) {
  const colors = {
    neutral: "var(--text-primary)",
    up: "var(--price-up)",
    down: "var(--price-down)",
    warn: "var(--warn-500)",
    accent: "var(--accent-press)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      padding: emphasis ? "12px 16px" : "0",
      borderRadius: emphasis ? "var(--radius-md)" : 0,
      background: emphasis ? "var(--surface-inset)" : "transparent",
      border: emphasis ? "1px solid var(--border-subtle)" : "none",
      minWidth: 0,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-tertiary)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: emphasis ? "var(--text-xl)" : "var(--text-lg)",
      fontWeight: "var(--weight-bold)",
      fontVariantNumeric: "tabular-nums lining-nums",
      letterSpacing: "var(--tracking-tight)",
      color: colors[accent] || colors.neutral,
      lineHeight: 1.1,
      whiteSpace: "nowrap"
    }
  }, value), sub && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)",
      fontFamily: "var(--font-mono)"
    }
  }, sub));
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/StatTile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/stockclash/App.jsx
try { (() => {
/* StockClash UI kit — App shell: routing + demo chrome. */
const {
  Badge,
  SegmentedControl
} = window.StockClashDesignSystem_2f48a1;
function App() {
  const [screen, setScreen] = React.useState("home");
  const [online, setOnline] = React.useState(true);
  const [variant, setVariant] = React.useState("classic");
  const candles = React.useMemo(() => window.genCandles(7, 84, 100, 0.006, 0.02), []);
  const screens = [{
    id: "home",
    label: "大厅"
  }, {
    id: "room",
    label: "房间"
  }, {
    id: "trade",
    label: "交易"
  }, {
    id: "settle",
    label: "结算"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      background: "var(--surface-app)",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 50,
      height: 54,
      flexShrink: 0,
      display: "flex",
      alignItems: "center",
      gap: 16,
      padding: "0 18px",
      background: "color-mix(in srgb, var(--surface-card) 88%, transparent)",
      backdropFilter: "blur(8px)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement(window.Wordmark, {
    size: 18
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 22,
      background: "var(--border-default)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4
    }
  }, screens.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.id,
    onClick: () => setScreen(s.id),
    style: {
      height: 32,
      padding: "0 14px",
      borderRadius: "var(--radius-sm)",
      border: "none",
      cursor: "pointer",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-sm)",
      fontWeight: 600,
      color: screen === s.id ? "var(--text-primary)" : "var(--text-tertiary)",
      background: screen === s.id ? "var(--surface-sunken)" : "transparent"
    }
  }, s.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), screen === "trade" && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)"
    }
  }, "\u5E03\u5C40"), /*#__PURE__*/React.createElement(SegmentedControl, {
    size: "sm",
    value: variant,
    onChange: setVariant,
    options: [{
      value: "classic",
      label: "经典终端"
    }, {
      value: "focus",
      label: "聚焦操作"
    }, {
      value: "dense",
      label: "数据密集"
    }]
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, screen === "home" && /*#__PURE__*/React.createElement(window.Home, {
    onCreate: m => {
      setOnline(m === "online");
      setScreen("room");
    },
    onJoin: () => {
      setOnline(true);
      setScreen("room");
    }
  }), screen === "room" && /*#__PURE__*/React.createElement(window.Room, {
    online: online,
    onStart: () => setScreen("trade"),
    onLeave: () => setScreen("home")
  }), screen === "trade" && /*#__PURE__*/React.createElement(window.Trading, {
    variant: variant,
    candles: candles,
    onSettle: () => setScreen("settle"),
    onLoan: () => {}
  }), screen === "settle" && /*#__PURE__*/React.createElement(window.Settlement, {
    onAgain: () => setScreen("trade"),
    onRoom: () => setScreen("room")
  })));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/stockclash/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/stockclash/Chart.jsx
try { (() => {
/* StockClash UI kit — lightweight SVG candlestick chart with volume subchart.
   Pure data-viz from generated OHLC. Green up / red down. */

function CandleChart({
  candles,
  revealed,
  width = 640,
  height = 320,
  showVolume = true
}) {
  const data = candles.slice(0, revealed);
  const padL = 8,
    padR = 54,
    padT = 10,
    padB = 6;
  const volH = showVolume ? Math.round(height * 0.18) : 0;
  const gap = showVolume ? 8 : 0;
  const priceH = height - volH - gap - padT - padB;
  const plotW = width - padL - padR;
  const all = candles; // scale to the full series so axis is stable as it reveals
  const hi = Math.max(...all.map(c => c.h));
  const lo = Math.min(...all.map(c => c.l));
  const range = hi - lo || 1;
  const x = i => padL + (i + 0.5) * (plotW / all.length);
  const y = p => padT + (1 - (p - lo) / range) * priceH;
  const cw = Math.max(2, plotW / all.length * 0.62);
  const upC = "var(--price-up)",
    downC = "var(--price-down)";
  const last = data[data.length - 1];
  const lastY = last ? y(last.c) : 0;
  const lastUp = last ? last.c >= last.o : true;
  const maxV = Math.max(...all.map(c => c.v));
  const volY0 = padT + priceH + gap;

  // gridlines
  const lines = [0, 0.25, 0.5, 0.75, 1].map(f => {
    const p = lo + range * f;
    return {
      y: y(p),
      label: p.toFixed(1)
    };
  });
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${width} ${height}`,
    width: "100%",
    height: "100%",
    style: {
      display: "block",
      fontFamily: "var(--font-mono)"
    }
  }, lines.map((l, i) => /*#__PURE__*/React.createElement("g", {
    key: i
  }, /*#__PURE__*/React.createElement("line", {
    x1: padL,
    y1: l.y,
    x2: padL + plotW,
    y2: l.y,
    stroke: "var(--border-subtle)",
    strokeWidth: "1",
    strokeDasharray: "2 4"
  }), /*#__PURE__*/React.createElement("text", {
    x: width - padR + 6,
    y: l.y + 3,
    fontSize: "9",
    fill: "var(--text-tertiary)"
  }, l.label))), data.map((c, i) => {
    const up = c.c >= c.o;
    const col = up ? upC : downC;
    const oy = y(c.o),
      cy = y(c.c);
    const top = Math.min(oy, cy);
    const bh = Math.max(1.5, Math.abs(cy - oy));
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("line", {
      x1: x(i),
      y1: y(c.h),
      x2: x(i),
      y2: y(c.l),
      stroke: col,
      strokeWidth: "1"
    }), /*#__PURE__*/React.createElement("rect", {
      x: x(i) - cw / 2,
      y: top,
      width: cw,
      height: bh,
      fill: col,
      rx: "0.5"
    }), showVolume && /*#__PURE__*/React.createElement("rect", {
      x: x(i) - cw / 2,
      y: volY0 + volH - c.v / maxV * volH,
      width: cw,
      height: c.v / maxV * volH,
      fill: col,
      opacity: "0.35"
    }));
  }), last && /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("line", {
    x1: padL,
    y1: lastY,
    x2: padL + plotW,
    y2: lastY,
    stroke: lastUp ? upC : downC,
    strokeWidth: "1",
    strokeDasharray: "3 3",
    opacity: "0.7"
  }), /*#__PURE__*/React.createElement("rect", {
    x: width - padR,
    y: lastY - 8,
    width: padR - 2,
    height: "16",
    rx: "3",
    fill: lastUp ? upC : downC
  }), /*#__PURE__*/React.createElement("text", {
    x: width - padR / 2 - 1,
    y: lastY + 3,
    fontSize: "9.5",
    fontWeight: "700",
    fill: "#fff",
    textAnchor: "middle"
  }, last.c.toFixed(2))));
}
window.CandleChart = CandleChart;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/stockclash/Chart.jsx", error: String((e && e.message) || e) }); }

// ui_kits/stockclash/Home.jsx
try { (() => {
/* StockClash UI kit — Home / 大厅. Three entry points. */
const {
  Button,
  Card,
  Badge
} = window.StockClashDesignSystem_2f48a1;
function Home({
  onCreate,
  onJoin
}) {
  const entries = [{
    id: "local",
    icon: "monitor",
    title: "本地创建房间",
    sub: "1 名真人 + AI，无需联网",
    tone: "secondary"
  }, {
    id: "online",
    icon: "wifi",
    title: "联机创建房间",
    sub: "生成 6 位房间号，开黑连打",
    tone: "primary"
  }, {
    id: "join",
    icon: "log-in",
    title: "加入房间",
    sub: "输入房间号加入好友",
    tone: "secondary"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100%",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "48px 24px",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(window.Wordmark, {
    size: 44
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-lg)",
      color: "var(--text-secondary)",
      maxWidth: 460,
      lineHeight: 1.6
    }
  }, "\u4E00\u5C40\u56DB\u5206\u949F\uFF0C\u8DD1\u5B8C\u73B0\u5B9E\u91CC\u56DB\u4E2A\u6708\u7684\u884C\u60C5\u3002", /*#__PURE__*/React.createElement("br", null), "\u770B\u8C01\u662F\u80A1\u795E\uFF0C\u8C01\u5728\u88AB\u5272\u97ED\u83DC\u3002"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "up",
    dot: true
  }, "\u5B9E\u65F6 K \u7EBF"), /*#__PURE__*/React.createElement(Badge, {
    tone: "accent"
  }, "\u505A\u591A\u505A\u7A7A \xB7 \u6760\u6746"), /*#__PURE__*/React.createElement(Badge, {
    tone: "info"
  }, "4 \u4EBA\u540C\u53F0"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 240px)",
      gap: 16,
      maxWidth: "100%"
    }
  }, entries.map(e => /*#__PURE__*/React.createElement("button", {
    key: e.id,
    onClick: () => e.id === "join" ? onJoin() : onCreate(e.id),
    style: {
      textAlign: "left",
      cursor: "pointer",
      background: "var(--surface-card)",
      border: `1px solid ${e.tone === "primary" ? "var(--accent-soft-border)" : "var(--border-default)"}`,
      boxShadow: e.tone === "primary" ? "var(--glow-gold)" : "var(--shadow-card)",
      borderRadius: "var(--radius-xl)",
      padding: 22,
      display: "flex",
      flexDirection: "column",
      gap: 14,
      transition: "transform var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)"
    },
    onMouseEnter: ev => {
      ev.currentTarget.style.transform = "translateY(-3px)";
      ev.currentTarget.style.boxShadow = "var(--shadow-lg)";
    },
    onMouseLeave: ev => {
      ev.currentTarget.style.transform = "";
      ev.currentTarget.style.boxShadow = e.tone === "primary" ? "var(--glow-gold)" : "var(--shadow-card)";
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 46,
      borderRadius: "var(--radius-md)",
      background: e.tone === "primary" ? "var(--accent)" : "var(--surface-sunken)",
      color: e.tone === "primary" ? "var(--on-accent)" : "var(--accent-press)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(window.Icon, {
    name: e.icon,
    size: 24
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-lg)",
      fontWeight: 700,
      color: "var(--text-primary)"
    }
  }, e.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-secondary)",
      marginTop: 4
    }
  }, e.sub)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      fontSize: "var(--text-sm)",
      fontWeight: 600,
      color: e.tone === "primary" ? "var(--accent-press)" : "var(--text-tertiary)",
      marginTop: 2
    }
  }, "\u8FDB\u5165 ", /*#__PURE__*/React.createElement(window.Icon, {
    name: "chevron-right",
    size: 15
  }))))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)",
      textAlign: "center"
    }
  }, "\u5386\u53F2\u884C\u60C5\u4EC5\u4F5C\u6E38\u620F\u5316\u5A31\u4E50\u7528\u9014\uFF0C\u8D39\u7387/\u5229\u7387\u4E3A\u53EF\u8C03\u5E73\u8861\u6570\u503C\uFF0C\u4E0D\u6784\u6210\u4EFB\u4F55\u6295\u8D44\u5EFA\u8BAE\u3002"));
}
window.Home = Home;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/stockclash/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/stockclash/Room.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* StockClash UI kit — Room / 房间 (统一房间视图). Host config + seats. */
const {
  Button,
  Card,
  Badge,
  SegmentedControl,
  SourceChip,
  Switch,
  SeatTile
} = window.StockClashDesignSystem_2f48a1;
function Room({
  online = true,
  onStart,
  onLeave
}) {
  const [src, setSrc] = React.useState({
    cn: true,
    hk: true,
    us: false,
    crypto: true
  });
  const [tier, setTier] = React.useState("std");
  const [blind, setBlind] = React.useState(online);
  const [items, setItems] = React.useState(true);
  const [freeSwap, setFreeSwap] = React.useState(true);
  const [seats, setSeats] = React.useState([{
    seat: 1,
    type: "human",
    name: "你",
    host: true,
    you: true
  }, {
    seat: 2,
    type: "human",
    name: "听雪"
  }, {
    seat: 3,
    type: "human",
    name: "青锋"
  }, {
    seat: 4,
    type: "ai",
    ai: "normal"
  }, {
    seat: 5,
    type: "ai",
    ai: "hard"
  }, {
    seat: 6,
    type: "empty"
  }]);
  const cycleAi = i => setSeats(s => s.map((x, j) => j === i ? {
    ...x,
    ai: x.ai === "easy" ? "normal" : x.ai === "normal" ? "hard" : "easy"
  } : x));
  const kick = i => setSeats(s => s.map((x, j) => j === i ? {
    seat: x.seat,
    type: "empty"
  } : x));
  const filled = seats.filter(s => s.type !== "empty").length;
  const RuleChip = ({
    icon,
    label,
    value
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "8px 12px",
      background: "var(--surface-inset)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)"
    }
  }, /*#__PURE__*/React.createElement(window.Icon, {
    name: icon,
    size: 15,
    color: "var(--text-tertiary)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      fontWeight: 600,
      color: "var(--text-primary)",
      fontFamily: "var(--font-mono)"
    }
  }, value));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: "0 auto",
      padding: "28px 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 22,
      flexWrap: "wrap",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(window.Wordmark, {
    size: 22
  }), /*#__PURE__*/React.createElement(Badge, {
    tone: online ? "info" : "neutral",
    dot: true
  }, online ? "联机房间" : "本地房间")), online && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--text-secondary)"
    }
  }, "\u623F\u95F4\u53F7"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xl)",
      fontWeight: 700,
      letterSpacing: "0.12em",
      color: "var(--accent-press)"
    }
  }, "ABC123"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "copy",
      size: 14
    })
  }, "\u590D\u5236\u9080\u8BF7"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    header: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(window.Icon, {
      name: "sliders-horizontal",
      size: 16,
      color: "var(--accent-press)"
    }), "\u89C4\u5219\u914D\u7F6E"),
    padding: "18px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: 600,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: "var(--text-tertiary)",
      marginBottom: 9
    }
  }, "K \u7EBF\u6765\u6E90\uFF08\u591A\u9009\uFF09"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, Object.keys(window.MARKETS).map(m => /*#__PURE__*/React.createElement(SourceChip, {
    key: m,
    market: m,
    label: window.MARKETS[m].label,
    checked: src[m],
    onChange: v => setSrc({
      ...src,
      [m]: v
    })
  })))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: 600,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: "var(--text-tertiary)",
      marginBottom: 9
    }
  }, "\u6863\u4F4D"), /*#__PURE__*/React.createElement(SegmentedControl, {
    value: tier,
    onChange: setTier,
    options: window.TIERS.map(t => ({
      value: t.value,
      label: t.label,
      star: t.star
    }))
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)",
      marginTop: 8
    }
  }, window.TIERS.find(t => t.value === tier).dur, " \u5C40\u65F6\u957F \xB7 \u8986\u76D6 ", window.TIERS.find(t => t.value === tier).win, " \u771F\u5B9E\u884C\u60C5 \xB7 \u6BCF 1s \u5237\u65B0")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(RuleChip, {
    icon: "wallet",
    label: "\u521D\u59CB\u8D44\u91D1",
    value: "\xA5100k"
  }), /*#__PURE__*/React.createElement(RuleChip, {
    icon: "receipt",
    label: "\u624B\u7EED\u8D39",
    value: "\u6807\u51C6"
  }), /*#__PURE__*/React.createElement(RuleChip, {
    icon: "percent",
    label: "\u8D37\u6B3E",
    value: "+2% / 30s"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 20,
      paddingTop: 4
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      fontSize: "var(--text-sm)",
      color: "var(--text-secondary)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: blind,
    onChange: setBlind
  }), " \u76F2\u76D2\u6A21\u5F0F"), /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      fontSize: "var(--text-sm)",
      color: "var(--text-secondary)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: items,
    onChange: setItems
  }), " \u9053\u5177\u6A21\u5F0F ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-tertiary)",
      fontFamily: "var(--font-mono)"
    }
  }, "60s"))))), /*#__PURE__*/React.createElement(Card, {
    header: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        width: "100%"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(window.Icon, {
      name: "users",
      size: 16,
      color: "var(--accent-press)"
    }), "\u5EA7\u4F4D"), /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral"
    }, filled, "/6")),
    padding: "18px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 9
    }
  }, seats.map((s, i) => /*#__PURE__*/React.createElement(SeatTile, _extends({
    key: i
  }, s, {
    canEdit: true,
    onKick: () => kick(i),
    onCycleAi: () => cycleAi(i)
  })))), /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      fontSize: "var(--text-sm)",
      color: "var(--text-secondary)",
      cursor: "pointer",
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    checked: freeSwap,
    onChange: setFreeSwap
  }), " \u5141\u8BB8\u73A9\u5BB6\u81EA\u7531\u7533\u8BF7\u6362\u5EA7"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      marginTop: 20,
      justifyContent: "flex-end"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: onLeave
  }, "\u9000\u51FA"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "play",
      size: 18
    }),
    onClick: onStart
  }, "\u5F00\u59CB\u6E38\u620F")));
}
window.Room = Room;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/stockclash/Room.jsx", error: String((e && e.message) || e) }); }

// ui_kits/stockclash/Settlement.jsx
try { (() => {
/* StockClash UI kit — Settlement / 结算. Final ranking + 净值曲线复盘. */
const {
  Button,
  Card,
  Badge,
  StatTile,
  LeaderboardRow
} = window.StockClashDesignSystem_2f48a1;
function NetCurve({
  seed,
  color,
  width = 560,
  height = 150
}) {
  const r = window.rng(seed);
  const n = 60;
  const pts = [];
  let v = 100000;
  for (let i = 0; i < n; i++) {
    v = Math.max(20000, v * (1 + (r() - 0.46) * 0.06));
    pts.push(v);
  }
  const hi = Math.max(...pts),
    lo = Math.min(...pts),
    rng_ = hi - lo || 1;
  const x = i => 6 + i * ((width - 12) / (n - 1));
  const y = p => 8 + (1 - (p - lo) / rng_) * (height - 16);
  const d = pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)} ${y(p).toFixed(1)}`).join(" ");
  const area = `${d} L${x(n - 1).toFixed(1)} ${height - 8} L6 ${height - 8} Z`;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${width} ${height}`,
    width: "100%",
    height: height,
    style: {
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "g" + seed,
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: color,
    stopOpacity: "0.18"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: color,
    stopOpacity: "0"
  }))), /*#__PURE__*/React.createElement("line", {
    x1: "6",
    y1: y(100000),
    x2: width - 6,
    y2: y(100000),
    stroke: "var(--border-strong)",
    strokeDasharray: "3 3",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: area,
    fill: `url(#g${seed})`
  }), /*#__PURE__*/React.createElement("path", {
    d: d,
    fill: "none",
    stroke: color,
    strokeWidth: "2",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }));
}
function Settlement({
  onAgain,
  onRoom
}) {
  const finals = [{
    id: "you",
    name: "你",
    net: 132400,
    ret: 32.4,
    dd: 11.2,
    trades: 18,
    ai: null,
    you: true
  }, {
    id: "p2",
    name: "听雪",
    net: 119000,
    ret: 19.0,
    dd: 14.0,
    trades: 22,
    ai: null
  }, {
    id: "p5",
    name: "墨白",
    net: 104300,
    ret: 4.3,
    dd: 9.5,
    trades: 12,
    ai: "normal"
  }, {
    id: "p3",
    name: "北辰",
    net: 98200,
    ret: -1.8,
    dd: 22.0,
    trades: 31,
    ai: "hard"
  }, {
    id: "p4",
    name: "青锋",
    net: 0,
    ret: -100,
    dd: 100,
    trades: 9,
    ai: "easy"
  }];
  const winner = finals[0];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1080,
      margin: "0 auto",
      padding: "26px 24px 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      marginBottom: 20,
      padding: "18px 22px",
      borderRadius: "var(--radius-xl)",
      background: "linear-gradient(100deg, var(--gold-50), var(--surface-card))",
      border: "1px solid var(--accent-soft-border)",
      boxShadow: "var(--glow-gold)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 52,
      height: 52,
      borderRadius: "50%",
      background: "var(--accent)",
      color: "var(--on-accent)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(window.Icon, {
    name: "trophy",
    size: 26
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-xs)",
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      color: "var(--text-tertiary)",
      fontWeight: 600
    }
  }, "\u672C\u5C40\u80A1\u795E"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-2xl)",
      fontWeight: 700,
      color: "var(--text-primary)"
    }
  }, winner.name, " \xB7 \u4F60")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-3xl)",
      fontWeight: 700,
      color: "var(--price-up)",
      letterSpacing: "-0.02em"
    }
  }, window.yuan(winner.net)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-sm)",
      fontWeight: 600,
      color: "var(--price-up)"
    }
  }, window.pct(winner.ret), " \u6536\u76CA\u7387"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 380px",
      gap: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    header: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        width: "100%"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(window.Icon, {
      name: "activity",
      size: 16,
      color: "var(--accent-press)"
    }), "\u51C0\u503C\u66F2\u7EBF\u590D\u76D8"), /*#__PURE__*/React.createElement(Badge, {
      tone: "cn",
      dot: true
    }, "\u8D35\u5DDE\u8305\u53F0 \xB7 2021-06 \u2192 10")),
    padding: "16px"
  }, /*#__PURE__*/React.createElement(NetCurve, {
    seed: 3,
    color: "var(--price-up)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 22,
      marginTop: 12,
      paddingTop: 12,
      borderTop: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "\u6536\u76CA\u7387",
    value: window.pct(winner.ret),
    accent: "up"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "\u6700\u5927\u56DE\u64A4",
    value: winner.dd.toFixed(1) + "%",
    accent: "down"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "\u4EA4\u6613\u6B21\u6570",
    value: winner.trades
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "\u76F2\u76D2\u63ED\u6653",
    value: "\u8D35\u5DDE\u8305\u53F0",
    accent: "accent"
  }))), /*#__PURE__*/React.createElement(Card, {
    header: /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(window.Icon, {
      name: "list-ordered",
      size: 16,
      color: "var(--accent-press)"
    }), "\u6700\u7EC8\u6392\u540D"),
    padding: "12px"
  }, finals.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: f.id,
    style: {
      borderBottom: i < finals.length - 1 ? "1px solid var(--border-subtle)" : "none"
    }
  }, /*#__PURE__*/React.createElement(LeaderboardRow, {
    rank: i + 1,
    name: f.name,
    net: window.yuan(f.net),
    deltaPct: f.ret,
    you: f.you,
    ai: f.ai,
    broke: f.net <= 0
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      marginTop: 20,
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "users",
      size: 18
    }),
    onClick: onRoom
  }, "\u56DE\u5230\u623F\u95F4"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "rotate-ccw",
      size: 18
    }),
    onClick: onAgain
  }, "\u518D\u6765\u4E00\u5C40")));
}
window.Settlement = Settlement;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/stockclash/Settlement.jsx", error: String((e && e.message) || e) }); }

// ui_kits/stockclash/Trading.jsx
try { (() => {
/* StockClash UI kit — Trading / 交易主界面. Three layout variants share these pieces. */
const {
  Button,
  Card,
  Badge,
  PriceTag,
  StatTile,
  LeaderboardRow,
  Countdown,
  PropCard,
  SegmentedControl,
  NumberStepper,
  IconButton
} = window.StockClashDesignSystem_2f48a1;

// ---------- shared sub-pieces ----------
function InstrumentHead({
  name,
  candle,
  prevClose,
  blind,
  big
}) {
  const changePct = (candle.c - prevClose) / prevClose * 100;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: big ? "var(--text-xl)" : "var(--text-lg)",
      fontWeight: 700,
      color: "var(--text-primary)"
    }
  }, blind ? "标的 A" : name), blind ? /*#__PURE__*/React.createElement(Badge, {
    tone: "warn",
    dot: true
  }, "\u76F2\u76D2") : /*#__PURE__*/React.createElement(Badge, {
    tone: "cn"
  }, "\u5927 A")), !blind && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-tertiary)"
    }
  }, "SH600519 \xB7 \u65E5 K \u52A0\u901F\u56DE\u653E")), /*#__PURE__*/React.createElement(PriceTag, {
    price: candle.c,
    changePct: changePct,
    size: big ? "lg" : "md"
  }));
}
function HUD({
  pf,
  compact
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: compact ? 16 : 22,
      flexWrap: "wrap",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "\u73B0\u91D1",
    value: window.yuan(pf.cash)
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "\u6301\u4ED3",
    value: (pf.pos > 0 ? "+" : "") + pf.pos + " 股",
    accent: pf.pos > 0 ? "up" : "neutral"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "\u8D1F\u503A",
    value: window.yuan(pf.debt),
    accent: pf.debt > 0 ? "warn" : "neutral"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "\u51C0\u503C",
    value: window.yuan(pf.net),
    accent: pf.net >= 100000 ? "up" : "down",
    sub: window.pct((pf.net - 100000) / 1000),
    emphasis: !compact
  }));
}
function QuickAmount({
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement(SegmentedControl, {
    size: "sm",
    value: value,
    onChange: onChange,
    options: ["25", "50", "100"].map(v => ({
      value: v,
      label: v + "%"
    }))
  });
}
function TradeActions({
  qty,
  setQty,
  pct,
  setPct,
  compact,
  onLoan
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(NumberStepper, {
    value: qty,
    step: 10,
    unit: "\u80A1",
    onChange: setQty
  }), /*#__PURE__*/React.createElement(QuickAmount, {
    value: pct,
    onChange: setPct
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "up",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "trending-up",
      size: 17
    })
  }, "\u4E70\u5165 / \u505A\u591A"), /*#__PURE__*/React.createElement(Button, {
    variant: "down",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "trending-down",
      size: 17
    })
  }, "\u505A\u7A7A"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "md"
  }, "\u5356\u51FA / \u5E73\u591A"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "md"
  }, "\u5E73\u7A7A")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "md",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "hand-coins",
      size: 16
    }),
    onClick: onLoan,
    style: {
      border: "1px solid var(--border-default)"
    }
  }, "\u8D37\u6B3E"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "md",
    iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
      name: "undo-2",
      size: 16
    }),
    style: {
      border: "1px solid var(--border-default)"
    }
  }, "\u8FD8\u6B3E")));
}
function Leaderboard({
  rows,
  compact
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 12px 8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: 600,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: "var(--text-tertiary)"
    }
  }, "\u5B9E\u65F6\u6392\u884C\u699C"), /*#__PURE__*/React.createElement(window.Icon, {
    name: "trophy",
    size: 14,
    color: "var(--accent)"
  })), rows.map((r, i) => /*#__PURE__*/React.createElement(LeaderboardRow, {
    key: r.id,
    rank: i + 1,
    name: r.name,
    net: window.yuan(r.net),
    deltaPct: (r.net - 100000) / 1000,
    you: r.you,
    ai: r.ai,
    broke: r.net <= 0
  })));
}
function PropBar({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: 600,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: "var(--text-tertiary)"
    }
  }, "\u9053\u5177\u680F"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, items.map((p, i) => /*#__PURE__*/React.createElement(PropCard, {
    key: i,
    compact: true,
    category: p.category,
    name: p.name,
    icon: /*#__PURE__*/React.createElement(window.Icon, {
      name: p.icon,
      size: 20
    }),
    count: p.count,
    onUse: () => {}
  })), Array.from({
    length: 3 - items.length
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: "e" + i,
    style: {
      width: 52,
      height: 52,
      borderRadius: "var(--radius-md)",
      border: "1.5px dashed var(--border-strong)",
      background: "var(--surface-inset)"
    }
  }))));
}

// ---------- main ----------
function Trading({
  variant = "classic",
  candles,
  onSettle,
  onLoan
}) {
  const PERSIST = "sc_kit_revealed";
  const [revealed, setRevealed] = React.useState(() => {
    const s = parseInt(localStorage.getItem(PERSIST) || "", 10);
    return Number.isFinite(s) && s >= 30 && s <= candles.length ? s : 42;
  });
  const [playing, setPlaying] = React.useState(true);
  const [qty, setQty] = React.useState(120);
  const [pctSel, setPctSel] = React.useState("50");
  React.useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setRevealed(r => {
      const n = Math.min(candles.length, r + 1);
      localStorage.setItem(PERSIST, String(n));
      return n;
    }), 900);
    return () => clearInterval(t);
  }, [playing, candles.length]);
  const candle = candles[revealed - 1];
  const prevClose = candles[Math.max(0, revealed - 6)].c;
  const remaining = Math.max(0, Math.round((candles.length - revealed) / candles.length * 240));

  // fake portfolio driven by price
  const pos = 120;
  const cash = 82300;
  const net = Math.round(cash + pos * candle.c * 7.8);
  const pf = {
    cash,
    pos,
    debt: 0,
    net
  };

  // fake leaderboard, sorted
  const blind = false;
  const others = window.PLAYERS.map((p, i) => ({
    ...p,
    net: p.you ? net : Math.round(net * (0.74 + 0.2 * Math.sin(revealed / 9 + i)))
  }));
  const rows = [...others].sort((a, b) => b.net - a.net);
  const myProps = [{
    category: "info",
    name: "内幕消息",
    icon: "eye",
    count: 1
  }, {
    category: "buff",
    name: "止损盾",
    icon: "shield",
    count: 2
  }];
  const PlayCtl = () => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    size: "sm",
    variant: "soft",
    label: playing ? "暂停" : "播放",
    onClick: () => setPlaying(p => !p)
  }, /*#__PURE__*/React.createElement(window.Icon, {
    name: playing ? "pause" : "play",
    size: 15
  })), /*#__PURE__*/React.createElement(IconButton, {
    size: "sm",
    variant: "soft",
    label: "\u91CD\u7F6E",
    onClick: () => {
      setRevealed(42);
      localStorage.setItem(PERSIST, "42");
    }
  }, /*#__PURE__*/React.createElement(window.Icon, {
    name: "rotate-ccw",
    size: 15
  })));
  const chartCard = h => /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-lg)",
      padding: 10,
      height: h
    }
  }, /*#__PURE__*/React.createElement(window.CandleChart, {
    candles: candles,
    revealed: revealed,
    width: 680,
    height: h - 20
  }));

  // ===== VARIANT: classic (doc wireframe) =====
  if (variant === "classic") {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 1180,
        margin: "0 auto",
        padding: "18px 22px 30px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 14,
        flexWrap: "wrap",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(InstrumentHead, {
      name: "\u8D35\u5DDE\u8305\u53F0",
      candle: candle,
      prevClose: prevClose,
      blind: blind,
      big: true
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(PlayCtl, null), /*#__PURE__*/React.createElement(Countdown, {
      remaining: remaining,
      total: 240
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 320px",
        gap: 16,
        alignItems: "start"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 14
      }
    }, chartCard(360), /*#__PURE__*/React.createElement(Card, {
      padding: "16px"
    }, /*#__PURE__*/React.createElement(HUD, {
      pf: pf
    })), /*#__PURE__*/React.createElement(Card, {
      padding: "16px"
    }, /*#__PURE__*/React.createElement(TradeActions, {
      qty: qty,
      setQty: setQty,
      pct: pctSel,
      setPct: setPctSel,
      onLoan: onLoan
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(Card, {
      padding: "12px"
    }, /*#__PURE__*/React.createElement(Leaderboard, {
      rows: rows
    })), /*#__PURE__*/React.createElement(Card, {
      padding: "14px"
    }, /*#__PURE__*/React.createElement(PropBar, {
      items: myProps
    })))));
  }

  // ===== VARIANT: focus (big actions) =====
  if (variant === "focus") {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 1080,
        margin: "0 auto",
        padding: "18px 22px 30px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 16
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "cn",
      dot: true
    }, "\u5927 A \xB7 \u8D35\u5DDE\u8305\u53F0"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(PlayCtl, null), /*#__PURE__*/React.createElement(Countdown, {
      remaining: remaining,
      total: 240,
      size: "sm"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "center",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 6,
        margin: "6px 0 16px"
      }
    }, /*#__PURE__*/React.createElement(PriceTag, {
      price: candle.c,
      changePct: (candle.c - prevClose) / prevClose * 100,
      size: "lg"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "var(--text-sm)",
        color: "var(--text-tertiary)"
      }
    }, "\u51C0\u503C ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: net >= 100000 ? "var(--price-up)" : "var(--price-down)",
        fontFamily: "var(--font-mono)"
      }
    }, window.yuan(net)), " \xB7 ", window.pct((net - 100000) / 1000))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 300px",
        gap: 16,
        alignItems: "start"
      }
    }, chartCard(330), /*#__PURE__*/React.createElement(Card, {
      padding: "12px"
    }, /*#__PURE__*/React.createElement(Leaderboard, {
      rows: rows
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 16,
        background: "var(--surface-card)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-xl)",
        boxShadow: "var(--shadow-md)",
        padding: 16,
        display: "flex",
        alignItems: "center",
        gap: 16,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(HUD, {
      pf: pf,
      compact: true
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement(NumberStepper, {
      value: qty,
      step: 10,
      unit: "\u80A1",
      onChange: setQty
    }), /*#__PURE__*/React.createElement(QuickAmount, {
      value: pctSel,
      onChange: setPctSel
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "up",
      size: "lg",
      iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
        name: "trending-up",
        size: 18
      })
    }, "\u4E70\u5165"), /*#__PURE__*/React.createElement(Button, {
      variant: "down",
      size: "lg",
      iconLeft: /*#__PURE__*/React.createElement(window.Icon, {
        name: "trending-down",
        size: 18
      })
    }, "\u505A\u7A7A"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "lg",
      onClick: onLoan,
      style: {
        border: "1px solid var(--border-default)"
      }
    }, "\u8D37\u6B3E")));
  }

  // ===== VARIANT: dense (data-heavy) =====
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: "0 auto",
      padding: "14px 18px 26px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 12,
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(InstrumentHead, {
    name: "\u8D35\u5DDE\u8305\u53F0",
    candle: candle,
    prevClose: prevClose,
    blind: blind
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(HUD, {
    pf: pf,
    compact: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(PlayCtl, null), /*#__PURE__*/React.createElement(Countdown, {
    remaining: remaining,
    total: 240,
    size: "sm"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "288px 1fr 290px",
      gap: 12,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "12px"
  }, /*#__PURE__*/React.createElement(Leaderboard, {
    rows: rows,
    compact: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, chartCard(316), /*#__PURE__*/React.createElement(Card, {
    padding: "12px"
  }, /*#__PURE__*/React.createElement(PropBar, {
    items: myProps
  }))), /*#__PURE__*/React.createElement(Card, {
    padding: "14px"
  }, /*#__PURE__*/React.createElement(TradeActions, {
    qty: qty,
    setQty: setQty,
    pct: pctSel,
    setPct: setPctSel,
    onLoan: onLoan,
    compact: true
  }))));
}
window.Trading = Trading;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/stockclash/Trading.jsx", error: String((e && e.message) || e) }); }

// ui_kits/stockclash/lib.jsx
try { (() => {
/* StockClash UI kit — shared helpers, fake data, Lucide icon wrapper.
   Loaded as a babel script; everything attaches to window for sibling screens. */

// ---- Lucide icon wrapper (real icons, CDN-loaded) ----
function Icon({
  name,
  size = 18,
  stroke = 2,
  color = "currentColor",
  style = {}
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = `<i data-lucide="${name}"></i>`;
      window.lucide.createIcons({
        nameAttr: "data-lucide",
        attrs: {
          width: size,
          height: size,
          "stroke-width": stroke
        }
      });
    }
  });
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: size,
      height: size,
      color,
      ...style
    }
  });
}

// ---- Formatting ----
const yuan = n => "¥" + Math.round(n).toLocaleString("en-US");
const pct = n => (n > 0 ? "+" : "") + n.toFixed(2) + "%";

// ---- Seeded RNG (mulberry32) for reproducible candles ----
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// Generate a believable OHLC series with a trend + volatility
function genCandles(seed = 7, n = 84, start = 100, drift = 0.004, vol = 0.018) {
  const r = rng(seed);
  const out = [];
  let prev = start;
  for (let i = 0; i < n; i++) {
    const wobble = (r() - 0.5) * 2;
    const trend = drift * (1 + Math.sin(i / 11));
    const o = prev;
    const c = Math.max(2, o * (1 + trend + wobble * vol));
    const hi = Math.max(o, c) * (1 + r() * vol * 0.8);
    const lo = Math.min(o, c) * (1 - r() * vol * 0.8);
    out.push({
      o,
      h: hi,
      l: lo,
      c,
      v: 0.3 + r()
    });
    prev = c;
  }
  return out;
}

// ---- Markets & instruments ----
const MARKETS = {
  cn: {
    id: "cn",
    label: "大 A",
    color: "var(--mkt-cn)"
  },
  hk: {
    id: "hk",
    label: "港股",
    color: "var(--mkt-hk)"
  },
  us: {
    id: "us",
    label: "美股",
    color: "var(--mkt-us)"
  },
  crypto: {
    id: "crypto",
    label: "虚拟货币",
    color: "var(--mkt-crypto)"
  }
};
const TIERS = [{
  value: "fast",
  label: "闪电",
  dur: "2 min",
  win: "2 个月"
}, {
  value: "std",
  label: "标准",
  star: true,
  dur: "4 min",
  win: "4 个月"
}, {
  value: "long",
  label: "长局",
  dur: "8 min",
  win: "1 年"
}, {
  value: "custom",
  label: "自定义",
  dur: "1–15 min",
  win: "1 周–3 年"
}];

// ---- Players (leaderboard / seats) ----
const PLAYERS = [{
  id: "you",
  name: "你",
  you: true,
  host: true,
  ai: null
}, {
  id: "p2",
  name: "听雪",
  ai: null
}, {
  id: "p3",
  name: "北辰",
  ai: "hard"
}, {
  id: "p4",
  name: "青锋",
  ai: "easy"
}, {
  id: "p5",
  name: "墨白",
  ai: "normal"
}];

// ---- Props (道具) ----
const PROPS = [{
  id: "insider",
  name: "内幕消息",
  category: "info",
  icon: "eye",
  desc: "看未来 3 tick 的方向"
}, {
  id: "swan",
  name: "黑天鹅",
  category: "pvp",
  icon: "bird",
  desc: "向对手砸盘一次"
}, {
  id: "free",
  name: "免单券",
  category: "buff",
  icon: "ticket",
  desc: "本笔交易免手续费"
}, {
  id: "shield",
  name: "止损盾",
  category: "buff",
  icon: "shield",
  desc: "免疫一次爆仓"
}, {
  id: "hike",
  name: "加息冲击",
  category: "pvp",
  icon: "trending-up",
  desc: "抬高对手贷款利率"
}, {
  id: "freeze",
  name: "冻结",
  category: "pvp",
  icon: "snowflake",
  desc: "对手数秒不能交易"
}, {
  id: "dip",
  name: "抄底券",
  category: "buff",
  icon: "anchor",
  desc: "双倍杠杆一次"
}];

// ---- Brand wordmark (typographic logo) ----
function Wordmark({
  size = 28,
  stacked = false,
  mono = false
}) {
  const gold = mono ? "currentColor" : "var(--accent)";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: stacked ? "flex-start" : "baseline",
      flexDirection: stacked ? "column" : "row",
      gap: stacked ? 2 : 9,
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: size,
      letterSpacing: "0.04em",
      color: "var(--text-primary)",
      display: "inline-flex",
      alignItems: "center",
      gap: 2
    }
  }, "\u64CD", /*#__PURE__*/React.createElement("span", {
    style: {
      color: gold
    }
  }, "\u76D8"), "\u6740"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: size * 0.5,
      letterSpacing: "0.22em",
      textTransform: "uppercase",
      color: "var(--text-tertiary)"
    }
  }, "StockClash"));
}
Object.assign(window, {
  Icon,
  yuan,
  pct,
  rng,
  genCandles,
  MARKETS,
  TIERS,
  PLAYERS,
  PROPS,
  Wordmark
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/stockclash/lib.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.NumberStepper = __ds_scope.NumberStepper;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.SourceChip = __ds_scope.SourceChip;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Countdown = __ds_scope.Countdown;

__ds_ns.LeaderboardRow = __ds_scope.LeaderboardRow;

__ds_ns.PriceTag = __ds_scope.PriceTag;

__ds_ns.PropCard = __ds_scope.PropCard;

__ds_ns.SeatTile = __ds_scope.SeatTile;

__ds_ns.StatTile = __ds_scope.StatTile;

})();
