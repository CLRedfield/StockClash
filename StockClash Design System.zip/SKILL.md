---
name: stockclash-design
description: Use this skill to generate well-branded interfaces and assets for 操盘杀 StockClash (a real-time stock-trading speed-competition game), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation
- **Light theme. Gold accent (`--gold-500 #c8932a`). 绿涨红跌** (green up, red down). Cool slate neutrals. Restrained — hairline-bordered cards, no glassmorphism on content, no photographic imagery, no emoji.
- **Fonts** (Google Fonts CDN; swap for self-hosted in production): Space Grotesk (display) + Noto Sans SC (Chinese body) + JetBrains Mono (all ticking numbers, `tabular-nums`).
- **Icons:** Lucide (2px stroke). CDN in prototypes; self-host `lucide` in production.
- **Tokens** live in `tokens/*.css`, all reachable from `styles.css` — link that one file.
- **Components** are React, exported under `window.StockClashDesignSystem_2f48a1` after loading `_ds_bundle.js`. See `components/<group>/<Name>.prompt.md` for usage.
- **UI kit** at `ui_kits/stockclash/` is the reference for full-screen composition (大厅 / 房间 / 交易×3 / 结算).

## Copy voice
Simplified Chinese, punchy gamer-finance tone, address the player as 你, let numbers carry the message, always show sign + grouped thousands, keep the "娱乐用途、非投资建议" disclaimer.
