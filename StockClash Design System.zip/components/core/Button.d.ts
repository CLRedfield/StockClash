import * as React from "react";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** Visual style. @default "primary" */
  variant?: "primary" | "secondary" | "ghost" | "danger" | "up" | "down";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Stretch to container width. @default false */
  block?: boolean;
  disabled?: boolean;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Primary action button. Gold = primary, secondary = hairline outline,
 * up/down map to the green-up/red-down trade actions.
 *
 * @startingPoint section="Core" subtitle="按钮:主色/次级/幽灵/涨/跌" viewport="700x180"
 */
export function Button(props: ButtonProps): JSX.Element;
