import * as React from "react";

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** @default "ghost" */
  variant?: "ghost" | "outline" | "soft" | "accent";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Accessible label (also the tooltip title). */
  label?: string;
  disabled?: boolean;
  style?: React.CSSProperties;
}

/** Square icon-only button. Children is the icon node. */
export function IconButton(props: IconButtonProps): JSX.Element;
