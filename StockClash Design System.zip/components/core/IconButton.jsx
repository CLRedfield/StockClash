import React from "react";

/**
 * Square icon-only button. Pass a Lucide <i data-lucide> node or any glyph as children.
 */
export function IconButton({
  children,
  variant = "ghost",
  size = "md",
  disabled = false,
  label,
  style = {},
  ...rest
}) {
  const sizes = { sm: 32, md: 40, lg: 48 };
  const dim = sizes[size] || sizes.md;
  const variants = {
    ghost:     { background: "transparent", color: "var(--text-secondary)", border: "1px solid transparent" },
    outline:   { background: "var(--surface-card)", color: "var(--text-primary)", border: "1px solid var(--border-default)" },
    soft:      { background: "var(--surface-sunken)", color: "var(--text-primary)", border: "1px solid transparent" },
    accent:    { background: "var(--accent-soft)", color: "var(--accent-press)", border: "1px solid var(--accent-soft-border)" },
  };
  const v = variants[variant] || variants.ghost;
  return (
    <button
      aria-label={label}
      title={label}
      disabled={disabled}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: dim,
        height: dim,
        borderRadius: "var(--radius-md)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        transition: "background var(--dur-fast) var(--ease-out), filter var(--dur-fast) var(--ease-out)",
        ...v,
        ...style,
      }}
      onMouseEnter={(e) => { if (!disabled && variant === "ghost") e.currentTarget.style.background = "var(--surface-sunken)"; }}
      onMouseLeave={(e) => { if (variant === "ghost") e.currentTarget.style.background = "transparent"; }}
      {...rest}
    >
      {children}
    </button>
  );
}
