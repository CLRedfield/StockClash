import React from "react";

/**
 * Surface card — hairline border leads, shadow is a soft lift.
 * `tone="raised"` adds the shadow; `tone="sunken"` insets it.
 */
export function Card({
  children,
  tone = "flat",
  padding = "20px",
  header = null,
  footer = null,
  glow = false,
  style = {},
  ...rest
}) {
  const tones = {
    flat:   { background: "var(--surface-card)", boxShadow: "var(--shadow-card)" },
    raised: { background: "var(--surface-card)", boxShadow: "var(--shadow-md)" },
    sunken: { background: "var(--surface-inset)", boxShadow: "none" },
  };
  const t = tones[tone] || tones.flat;
  return (
    <div
      style={{
        borderRadius: "var(--radius-lg)",
        border: "1px solid var(--border-subtle)",
        overflow: "hidden",
        ...t,
        ...(glow ? { boxShadow: "var(--glow-gold)", borderColor: "var(--accent-soft-border)" } : null),
        ...style,
      }}
      {...rest}
    >
      {header && (
        <div style={{
          padding: "14px 20px",
          borderBottom: "1px solid var(--border-subtle)",
          fontFamily: "var(--font-display)",
          fontWeight: "var(--weight-semibold)",
          fontSize: "var(--text-md)",
          color: "var(--text-primary)",
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>{header}</div>
      )}
      <div style={{ padding }}>{children}</div>
      {footer && (
        <div style={{
          padding: "12px 20px",
          borderTop: "1px solid var(--border-subtle)",
          background: "var(--surface-inset)",
        }}>{footer}</div>
      )}
    </div>
  );
}
