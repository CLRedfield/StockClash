Compact label pill for status and the four market categories.

```jsx
<Badge tone="cn" dot>大 A</Badge>
<Badge tone="up" dot>+3.2%</Badge>
<Badge tone="accent" solid>道具模式</Badge>
```

Tones: `neutral`, `accent` (gold), `up`/`down` (P&L), `info`, `warn`, and market hues `cn`/`hk`/`us`/`crypto`. `solid` fills; `dot` adds a status dot.
