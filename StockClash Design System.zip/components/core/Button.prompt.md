Primary action button — use for the single most important action in any view (开始游戏, 买入, 确认).

```jsx
<Button variant="primary" size="lg">开始游戏</Button>
<Button variant="up" iconLeft={icon}>买入 / 做多</Button>
<Button variant="down">做空</Button>
```

Variants: `primary` (gold, one per view), `secondary` (hairline outline), `ghost` (low emphasis), `danger`, and `up`/`down` for the green-up/red-down trade actions. Sizes `sm|md|lg`; `lg` (48px) for touch primary actions. `block` stretches full width.
