import React from "react";

/**
 * StockClash primary button.
 * Variants: primary (gold), secondary (outline), ghost, danger, up, down.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  block = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { height: "var(--control-sm)", padding: "0 12px", fontSize: "var(--text-sm)", gap: "6px", radius: "var(--radius-sm)" },
    md: { height: "var(--control-md)", padding: "0 18px", fontSize: "var(--text-base)", gap: "8px", radius: "var(--radius-md)" },
    lg: { height: "var(--control-lg)", padding: "0 26px", fontSize: "var(--text-md)", gap: "10px", radius: "var(--radius-md)" },
  };
  const variants = {
    primary:   { background: "var(--accent)", color: "var(--on-accent)", border: "1px solid transparent", boxShadow: "var(--shadow-xs)" },
    secondary: { background: "var(--surface-card)", color: "var(--text-primary)", border: "1px solid var(--border-strong)" },
    ghost:     { background: "transparent", color: "var(--text-secondary)", border: "1px solid transparent" },
    danger:    { background: "var(--danger-500)", color: "#fff", border: "1px solid transparent" },
    up:        { background: "var(--price-up)", color: "#fff", border: "1px solid transparent" },
    down:      { background: "var(--price-down)", color: "#fff", border: "1px solid transparent" },
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;

  return (
    <button
      disabled={disabled}
      style={{
        display: block ? "flex" : "inline-flex",
        width: block ? "100%" : "auto",
        alignItems: "center",
        justifyContent: "center",
        gap: s.gap,
        height: s.height,
        padding: s.padding,
        fontSize: s.fontSize,
        fontFamily: "var(--font-sans)",
        fontWeight: "var(--weight-semibold)",
        letterSpacing: "var(--tracking-tight)",
        lineHeight: 1,
        borderRadius: s.radius,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        transition: "transform var(--dur-fast) var(--ease-out), filter var(--dur-fast) var(--ease-out), background var(--dur-fast) var(--ease-out)",
        whiteSpace: "nowrap",
        ...v,
        ...style,
      }}
      onMouseDown={(e) => { if (!disabled) e.currentTarget.style.transform = "translateY(1px) scale(0.985)"; }}
      onMouseUp={(e) => { e.currentTarget.style.transform = ""; }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.filter = ""; }}
      onMouseEnter={(e) => { if (!disabled) e.currentTarget.style.filter = "brightness(0.96)"; }}
      {...rest}
    >
      {iconLeft}
      {children}
      {iconRight}
    </button>
  );
}
