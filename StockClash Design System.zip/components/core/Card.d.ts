import * as React from "react";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  /** @default "flat" */
  tone?: "flat" | "raised" | "sunken";
  /** CSS padding for the body. @default "20px" */
  padding?: string;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  /** Gold emphasis glow — use sparingly. @default false */
  glow?: boolean;
  style?: React.CSSProperties;
}

/** Surface container. Hairline border + optional soft shadow.
 * @startingPoint section="Core" subtitle="卡片:flat / raised / sunken" viewport="700x220" */
export function Card(props: CardProps): JSX.Element;
