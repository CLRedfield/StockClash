import React from "react";

/**
 * Compact label pill. Tones cover status + the four market hues.
 */
export function Badge({ children, tone = "neutral", solid = false, dot = false, style = {}, ...rest }) {
  const map = {
    neutral: ["var(--slate-600)", "var(--slate-100)", "var(--slate-200)"],
    accent:  ["var(--gold-700)", "var(--gold-50)", "var(--gold-200)"],
    up:      ["var(--price-up)", "var(--price-up-soft)", "var(--price-up-border)"],
    down:    ["var(--price-down)", "var(--price-down-soft)", "var(--price-down-border)"],
    info:    ["var(--info-500)", "var(--info-50)", "color-mix(in srgb, var(--info-500) 22%, transparent)"],
    warn:    ["var(--warn-500)", "var(--warn-50)", "color-mix(in srgb, var(--warn-500) 26%, transparent)"],
    cn:      ["var(--mkt-cn)", "color-mix(in srgb, var(--mkt-cn) 10%, white)", "color-mix(in srgb, var(--mkt-cn) 28%, transparent)"],
    hk:      ["var(--mkt-hk)", "color-mix(in srgb, var(--mkt-hk) 10%, white)", "color-mix(in srgb, var(--mkt-hk) 28%, transparent)"],
    us:      ["var(--mkt-us)", "color-mix(in srgb, var(--mkt-us) 10%, white)", "color-mix(in srgb, var(--mkt-us) 28%, transparent)"],
    crypto:  ["var(--mkt-crypto)", "color-mix(in srgb, var(--mkt-crypto) 12%, white)", "color-mix(in srgb, var(--mkt-crypto) 30%, transparent)"],
  };
  const [fg, bg, bd] = map[tone] || map.neutral;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "5px",
        height: "22px",
        padding: "0 9px",
        borderRadius: "var(--radius-pill)",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-xs)",
        fontWeight: "var(--weight-semibold)",
        letterSpacing: "var(--tracking-tight)",
        lineHeight: 1,
        whiteSpace: "nowrap",
        color: solid ? "#fff" : fg,
        background: solid ? fg : bg,
        border: `1px solid ${solid ? "transparent" : bd}`,
        ...style,
      }}
      {...rest}
    >
      {dot && <span style={{ width: 6, height: 6, borderRadius: 99, background: solid ? "#fff" : fg }} />}
      {children}
    </span>
  );
}
