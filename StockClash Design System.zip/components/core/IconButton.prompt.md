Square icon-only button for toolbars and seat controls (设置, 踢人, 加 AI). Always pass `label` for a tooltip + a11y.

```jsx
<IconButton variant="ghost" label="设置"><GearIcon /></IconButton>
<IconButton variant="accent" label="加 AI"><PlusIcon /></IconButton>
```

Variants: `ghost` (default, toolbar), `outline`, `soft`, `accent` (gold). Sizes `sm|md|lg`.
