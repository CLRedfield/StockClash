Surface container — the base for panels, room cards, settlement blocks. Hairline border leads; shadow is a soft lift.

```jsx
<Card header="房间 ABC123" tone="raised">…</Card>
<Card glow>highlighted CTA panel</Card>
```

`tone`: `flat` (default), `raised` (shadow), `sunken` (inset). `glow` adds a restrained gold emphasis — primary panels only. `header`/`footer` render bordered bands.
