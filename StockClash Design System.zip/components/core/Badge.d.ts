import * as React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "accent" | "up" | "down" | "info" | "warn" | "cn" | "hk" | "us" | "crypto";
  /** Filled instead of soft-tinted. @default false */
  solid?: boolean;
  /** Leading status dot. @default false */
  dot?: boolean;
  style?: React.CSSProperties;
}

/** Compact label pill — status + the four market hues (cn/hk/us/crypto). */
export function Badge(props: BadgeProps): JSX.Element;
