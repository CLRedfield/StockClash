import * as React from "react";

export interface SourceChipProps {
  /** Market category — drives the hue. @default "cn" */
  market?: "cn" | "hk" | "us" | "crypto";
  label?: React.ReactNode;
  checked?: boolean;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
  style?: React.CSSProperties;
}

/** Toggleable K线来源 chip with a market-colored checkbox. */
export function SourceChip(props: SourceChipProps): JSX.Element;
