import React from "react";

/**
 * Segmented control — single-select pill row.
 * Used for 档位 (闪电/标准/长局), quick-amount (25/50/100%), color convention, etc.
 */
export function SegmentedControl({ options = [], value, onChange, size = "md", style = {}, ...rest }) {
  const heights = { sm: 30, md: 38, lg: 46 };
  const h = heights[size] || heights.md;
  return (
    <div
      role="tablist"
      style={{
        display: "inline-flex",
        padding: 3,
        gap: 2,
        background: "var(--surface-sunken)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-md)",
        ...style,
      }}
      {...rest}
    >
      {options.map((opt) => {
        const o = typeof opt === "string" ? { value: opt, label: opt } : opt;
        const active = o.value === value;
        return (
          <button
            key={o.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange && onChange(o.value)}
            style={{
              height: h - 6,
              padding: "0 14px",
              border: "none",
              borderRadius: "var(--radius-sm)",
              cursor: "pointer",
              fontFamily: "var(--font-sans)",
              fontSize: "var(--text-sm)",
              fontWeight: "var(--weight-semibold)",
              letterSpacing: "var(--tracking-tight)",
              color: active ? "var(--text-primary)" : "var(--text-secondary)",
              background: active ? "var(--surface-card)" : "transparent",
              boxShadow: active ? "var(--shadow-sm)" : "none",
              transition: "all var(--dur-fast) var(--ease-out)",
              whiteSpace: "nowrap",
              display: "inline-flex", alignItems: "center", gap: 6,
            }}
          >
            {o.icon}{o.label}{o.star && <span style={{ color: "var(--accent)" }}>★</span>}
          </button>
        );
      })}
    </div>
  );
}
