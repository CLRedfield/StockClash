import * as React from "react";

export interface SegmentOption {
  value: string;
  label?: React.ReactNode;
  icon?: React.ReactNode;
  /** Render a gold ★ after the label (e.g. 标准 ★ default tier). */
  star?: boolean;
}

export interface SegmentedControlProps {
  options: (SegmentOption | string)[];
  value?: string;
  onChange?: (value: string) => void;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  style?: React.CSSProperties;
}

/** Single-select pill row — 档位, quick-amount, toggles between exclusive modes. */
export function SegmentedControl(props: SegmentedControlProps): JSX.Element;
