import React from "react";

const HUES = {
  cn:     "var(--mkt-cn)",
  hk:     "var(--mkt-hk)",
  us:     "var(--mkt-us)",
  crypto: "var(--mkt-crypto)",
};

/**
 * Toggleable market-source chip (K线来源 multiselect). Selected = filled hue tint + check.
 */
export function SourceChip({ market = "cn", label, checked = false, disabled = false, onChange, style = {}, ...rest }) {
  const hue = HUES[market] || "var(--slate-500)";
  return (
    <button
      role="checkbox"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange && onChange(!checked)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        height: 38,
        padding: "0 14px 0 12px",
        borderRadius: "var(--radius-pill)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        fontWeight: "var(--weight-semibold)",
        letterSpacing: "var(--tracking-tight)",
        color: checked ? hue : "var(--text-secondary)",
        background: checked ? `color-mix(in srgb, ${hue} 10%, white)` : "var(--surface-card)",
        border: `1px solid ${checked ? `color-mix(in srgb, ${hue} 38%, transparent)` : "var(--border-default)"}`,
        transition: "all var(--dur-fast) var(--ease-out)",
        ...style,
      }}
      {...rest}
    >
      <span style={{
        width: 18, height: 18, borderRadius: "var(--radius-xs)",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        background: checked ? hue : "transparent",
        border: `1.5px solid ${checked ? hue : "var(--border-strong)"}`,
        transition: "all var(--dur-fast) var(--ease-out)",
      }}>
        {checked && (
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
        )}
      </span>
      {label}
    </button>
  );
}
