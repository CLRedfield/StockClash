import React from "react";

/**
 * Number stepper — quantity / amount input for the trade panel.
 * Monospace tabular value with − / + steppers and an optional unit suffix.
 */
export function NumberStepper({ value = 0, step = 1, min = 0, max = Infinity, unit = "", onChange, style = {}, ...rest }) {
  const set = (v) => onChange && onChange(Math.max(min, Math.min(max, v)));
  const btn = {
    width: 38, height: 38, flexShrink: 0,
    border: "none", cursor: "pointer",
    background: "var(--surface-sunken)",
    color: "var(--text-secondary)",
    fontSize: 18, fontWeight: 600, lineHeight: 1,
    display: "inline-flex", alignItems: "center", justifyContent: "center",
  };
  return (
    <div style={{
      display: "inline-flex", alignItems: "stretch",
      height: 40,
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      overflow: "hidden",
      background: "var(--surface-card)",
      ...style,
    }} {...rest}>
      <button style={{ ...btn, borderRight: "1px solid var(--border-subtle)" }} onClick={() => set(value - step)}>−</button>
      <div style={{
        flex: 1, minWidth: 72,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 4,
        padding: "0 10px",
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-md)",
        fontWeight: "var(--weight-semibold)",
        fontVariantNumeric: "tabular-nums lining-nums",
        color: "var(--text-primary)",
      }}>
        {value.toLocaleString("en-US")}
        {unit && <span style={{ fontSize: "var(--text-xs)", color: "var(--text-tertiary)", fontFamily: "var(--font-sans)" }}>{unit}</span>}
      </div>
      <button style={{ ...btn, borderLeft: "1px solid var(--border-subtle)" }} onClick={() => set(value + step)}>+</button>
    </div>
  );
}
