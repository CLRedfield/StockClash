import * as React from "react";

export interface SwitchProps {
  checked?: boolean;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
  /** @default "md" */
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

/** Boolean toggle for room rules (盲盒 / 道具模式 / 自由换座). */
export function Switch(props: SwitchProps): JSX.Element;
