import React from "react";

/**
 * Toggle switch for boolean room rules (盲盒 / 道具模式 / 自由换座).
 */
export function Switch({ checked = false, disabled = false, onChange, size = "md", style = {}, ...rest }) {
  const dims = { sm: [36, 20, 16], md: [44, 24, 20] };
  const [w, hh, knob] = dims[size] || dims.md;
  return (
    <button
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange && onChange(!checked)}
      style={{
        position: "relative",
        width: w,
        height: hh,
        flexShrink: 0,
        borderRadius: "var(--radius-pill)",
        border: "none",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        padding: 0,
        background: checked ? "var(--accent)" : "var(--slate-300)",
        transition: "background var(--dur-base) var(--ease-out)",
        ...style,
      }}
      {...rest}
    >
      <span style={{
        position: "absolute",
        top: (hh - knob) / 2,
        left: checked ? w - knob - (hh - knob) / 2 : (hh - knob) / 2,
        width: knob, height: knob,
        borderRadius: "50%",
        background: "#fff",
        boxShadow: "var(--shadow-sm)",
        transition: "left var(--dur-base) var(--ease-out)",
      }} />
    </button>
  );
}
