import * as React from "react";

export interface NumberStepperProps {
  value?: number;
  step?: number;
  min?: number;
  max?: number;
  /** Suffix unit label, e.g. "股" or "¥". */
  unit?: string;
  onChange?: (value: number) => void;
  style?: React.CSSProperties;
}

/** Quantity / amount stepper with monospace tabular value. */
export function NumberStepper(props: NumberStepperProps): JSX.Element;
