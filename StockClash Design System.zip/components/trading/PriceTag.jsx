import React from "react";

/**
 * Price + change display. Green up / red down (international convention).
 * `direction` overrides auto-detection from `change`.
 */
export function PriceTag({ price, change = 0, changePct, direction, size = "md", showArrow = true, style = {}, ...rest }) {
  const dir = direction || (change > 0 ? "up" : change < 0 ? "down" : "flat");
  const color = dir === "up" ? "var(--price-up)" : dir === "down" ? "var(--price-down)" : "var(--price-flat)";
  const arrow = dir === "up" ? "▲" : dir === "down" ? "▼" : "—";
  const sizes = {
    sm: { price: "var(--text-md)", meta: "var(--text-2xs)", gap: 6 },
    md: { price: "var(--text-2xl)", meta: "var(--text-sm)", gap: 8 },
    lg: { price: "var(--text-4xl)", meta: "var(--text-md)", gap: 10 },
  };
  const s = sizes[size] || sizes.md;
  return (
    <div style={{ display: "inline-flex", alignItems: "baseline", gap: s.gap, fontFamily: "var(--font-mono)", ...style }} {...rest}>
      <span style={{
        fontSize: s.price, fontWeight: "var(--weight-bold)", color,
        fontVariantNumeric: "tabular-nums lining-nums", letterSpacing: "var(--tracking-tight)", lineHeight: 1,
      }}>{typeof price === "number" ? price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : price}</span>
      <span style={{
        display: "inline-flex", alignItems: "center", gap: 3,
        fontSize: s.meta, fontWeight: "var(--weight-semibold)", color,
        fontVariantNumeric: "tabular-nums",
      }}>
        {showArrow && <span style={{ fontSize: "0.85em" }}>{arrow}</span>}
        {changePct != null ? `${changePct > 0 ? "+" : ""}${changePct.toFixed(2)}%` : `${change > 0 ? "+" : ""}${change}`}
      </span>
    </div>
  );
}
