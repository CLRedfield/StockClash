import * as React from "react";

export interface SeatTileProps {
  /** Seat number (1-based). */
  seat: number;
  name?: string;
  /** @default "empty" */
  type?: "human" | "ai" | "empty";
  /** Crown badge. */
  host?: boolean;
  /** Highlight as the current player. */
  you?: boolean;
  /** AI difficulty (when type="ai"). @default "normal" */
  ai?: "easy" | "normal" | "hard";
  /** Show host controls (kick / cycle AI). */
  canEdit?: boolean;
  onKick?: () => void;
  onCycleAi?: () => void;
  onSwap?: () => void;
  style?: React.CSSProperties;
}

/** Room seat — human / AI补位 / empty, with host kick + difficulty controls. */
export function SeatTile(props: SeatTileProps): JSX.Element;
