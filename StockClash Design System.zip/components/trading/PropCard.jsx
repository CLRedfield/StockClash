import React from "react";

const CAT = {
  buff: ["增益", "var(--price-up)"],
  info: ["信息", "var(--info-500)"],
  pvp:  ["搅局", "var(--price-down)"],
};

/**
 * Prop / item card (道具模式). Category-tinted, with icon, name, and effect line.
 * `compact` renders the slot-bar variant.
 */
export function PropCard({ name, desc, category = "buff", icon = null, count = 1, disabled = false, compact = false, onUse, style = {}, ...rest }) {
  const [catLabel, color] = CAT[category] || CAT.buff;
  if (compact) {
    return (
      <button onClick={onUse} disabled={disabled} style={{
        position: "relative", width: 52, height: 52, flexShrink: 0,
        borderRadius: "var(--radius-md)", cursor: disabled ? "not-allowed" : "pointer",
        background: `color-mix(in srgb, ${color} 9%, white)`,
        border: `1px solid color-mix(in srgb, ${color} 32%, transparent)`,
        display: "inline-flex", alignItems: "center", justifyContent: "center", color,
        opacity: disabled ? 0.5 : 1, ...style,
      }} title={name} {...rest}>
        {icon}
        {count > 1 && <span style={{
          position: "absolute", top: -6, right: -6, minWidth: 18, height: 18, padding: "0 4px",
          borderRadius: 99, background: color, color: "#fff", fontSize: 11, fontWeight: 700,
          fontFamily: "var(--font-mono)", display: "inline-flex", alignItems: "center", justifyContent: "center",
        }}>{count}</span>}
      </button>
    );
  }
  return (
    <div style={{
      display: "flex", flexDirection: "column", gap: 10, padding: 14, width: 180,
      borderRadius: "var(--radius-lg)", background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)", boxShadow: "var(--shadow-card)", ...style,
    }} {...rest}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{
          width: 38, height: 38, borderRadius: "var(--radius-md)",
          background: `color-mix(in srgb, ${color} 12%, white)`, color,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
        }}>{icon}</span>
        <span style={{
          fontSize: "var(--text-2xs)", fontWeight: 700, padding: "2px 8px", borderRadius: 99,
          color, background: `color-mix(in srgb, ${color} 10%, white)`,
          border: `1px solid color-mix(in srgb, ${color} 26%, transparent)`,
        }}>{catLabel}</span>
      </div>
      <div>
        <div style={{ fontSize: "var(--text-md)", fontWeight: "var(--weight-bold)", color: "var(--text-primary)", fontFamily: "var(--font-display)" }}>{name}</div>
        <div style={{ fontSize: "var(--text-xs)", color: "var(--text-secondary)", lineHeight: 1.5, marginTop: 4 }}>{desc}</div>
      </div>
      <button onClick={onUse} disabled={disabled} style={{
        height: 32, border: "none", borderRadius: "var(--radius-sm)", cursor: disabled ? "not-allowed" : "pointer",
        background: color, color: "#fff", fontSize: "var(--text-sm)", fontWeight: 600, fontFamily: "var(--font-sans)",
        opacity: disabled ? 0.5 : 1,
      }}>使用{category === "pvp" ? " · 选目标" : ""}</button>
    </div>
  );
}
