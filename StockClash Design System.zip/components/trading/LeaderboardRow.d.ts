import * as React from "react";

export interface LeaderboardRowProps {
  rank: number;
  name: string;
  /** Pre-formatted net worth string, e.g. "¥132,400". */
  net: React.ReactNode;
  /** Return % since start; colors the delta. */
  deltaPct?: number;
  /** Highlight as the current player. */
  you?: boolean;
  /** AI difficulty chip — null for humans. */
  ai?: "easy" | "normal" | "hard" | null;
  /** Bankrupt (净值 ≤ 0) — dims the row. */
  broke?: boolean;
  style?: React.CSSProperties;
}

/** One row of the live 排行榜. Rank medal, avatar, net worth, trend. */
export function LeaderboardRow(props: LeaderboardRowProps): JSX.Element;
