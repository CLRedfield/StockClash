import * as React from "react";

export interface CountdownProps {
  /** Seconds remaining. */
  remaining: number;
  /** Total seconds, for the progress track. @default 240 */
  total?: number;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  style?: React.CSSProperties;
}

/** Match timer mm:ss + progress; warns ≤30s, pulses danger ≤15s. */
export function Countdown(props: CountdownProps): JSX.Element;
