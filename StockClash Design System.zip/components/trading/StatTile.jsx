import React from "react";

/**
 * Labeled metric tile for the trade HUD — 现金 / 持仓 / 负债 / 净值.
 * `accent` tints the value (e.g. up/down for 净值 P&L, warn for 负债).
 */
export function StatTile({ label, value, sub, accent = "neutral", emphasis = false, style = {}, ...rest }) {
  const colors = {
    neutral: "var(--text-primary)",
    up: "var(--price-up)",
    down: "var(--price-down)",
    warn: "var(--warn-500)",
    accent: "var(--accent-press)",
  };
  return (
    <div style={{
      display: "flex", flexDirection: "column", gap: 4,
      padding: emphasis ? "12px 16px" : "0",
      borderRadius: emphasis ? "var(--radius-md)" : 0,
      background: emphasis ? "var(--surface-inset)" : "transparent",
      border: emphasis ? "1px solid var(--border-subtle)" : "none",
      minWidth: 0,
      ...style,
    }} {...rest}>
      <span style={{
        fontSize: "var(--text-2xs)", fontWeight: "var(--weight-semibold)",
        letterSpacing: "var(--tracking-caps)", textTransform: "uppercase",
        color: "var(--text-tertiary)",
      }}>{label}</span>
      <span style={{
        fontFamily: "var(--font-mono)",
        fontSize: emphasis ? "var(--text-xl)" : "var(--text-lg)",
        fontWeight: "var(--weight-bold)",
        fontVariantNumeric: "tabular-nums lining-nums",
        letterSpacing: "var(--tracking-tight)",
        color: colors[accent] || colors.neutral,
        lineHeight: 1.1, whiteSpace: "nowrap",
      }}>{value}</span>
      {sub && <span style={{ fontSize: "var(--text-xs)", color: "var(--text-secondary)", fontFamily: "var(--font-mono)" }}>{sub}</span>}
    </div>
  );
}
