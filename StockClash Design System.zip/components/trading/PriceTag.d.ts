import * as React from "react";

export interface PriceTagProps {
  price: number | string;
  /** Absolute change; sign auto-colors when `direction` omitted. */
  change?: number;
  /** Percent change; preferred for the meta label. */
  changePct?: number;
  /** Force the color/arrow regardless of `change`. */
  direction?: "up" | "down" | "flat";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  showArrow?: boolean;
  style?: React.CSSProperties;
}

/** Live price + change, green-up/red-down, monospace tabular. */
export function PriceTag(props: PriceTagProps): JSX.Element;
