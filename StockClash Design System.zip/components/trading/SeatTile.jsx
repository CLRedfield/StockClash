import React from "react";

const DIFF = { easy: ["简", "var(--slate-500)"], normal: ["普", "var(--info-500)"], hard: ["难", "var(--mkt-us)"] };

/**
 * Room seat tile — a human player, an AI补位, or an empty seat.
 * Host controls (kick ✕ / AI difficulty cycle) are surfaced when `canEdit`.
 */
export function SeatTile({ seat, name, type = "empty", host = false, you = false, ai = "normal", canEdit = false, onKick, onCycleAi, onSwap, style = {}, ...rest }) {
  const empty = type === "empty";
  const isAi = type === "ai";
  const [glyph, aiColor] = DIFF[ai] || DIFF.normal;
  return (
    <div style={{
      position: "relative",
      display: "flex", alignItems: "center", gap: 11,
      height: 60, padding: "0 14px",
      borderRadius: "var(--radius-lg)",
      background: empty ? "var(--surface-inset)" : "var(--surface-card)",
      border: `1px ${empty ? "dashed" : "solid"} ${you ? "var(--accent)" : "var(--border-default)"}`,
      boxShadow: empty ? "none" : "var(--shadow-card)",
      ...style,
    }} {...rest}>
      <span style={{
        fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", fontWeight: 700,
        color: "var(--text-tertiary)", width: 18, flexShrink: 0,
      }}>#{seat}</span>
      <span style={{
        width: 34, height: 34, borderRadius: "50%", flexShrink: 0,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        background: empty ? "transparent" : isAi ? `color-mix(in srgb, ${aiColor} 14%, white)` : you ? "var(--accent)" : "var(--surface-sunken)",
        border: empty ? "1.5px dashed var(--border-strong)" : "none",
        color: isAi ? aiColor : you ? "var(--on-accent)" : "var(--text-secondary)",
        fontSize: "var(--text-sm)", fontWeight: 700, fontFamily: "var(--font-display)",
      }}>{empty ? "" : isAi ? "AI" : String(name || "").slice(0, 1)}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: "var(--text-sm)", fontWeight: "var(--weight-semibold)", color: empty ? "var(--text-tertiary)" : "var(--text-primary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {empty ? "空位" : isAi ? "AI 补位" : name}
          </span>
          {host && <span title="房主" style={{ color: "var(--gold-500)" }}>♛</span>}
          {you && <span style={{ fontSize: "var(--text-2xs)", color: "var(--accent-press)", fontWeight: 700 }}>你</span>}
        </div>
      </div>
      {isAi && (
        <button onClick={() => canEdit && onCycleAi && onCycleAi()} disabled={!canEdit} style={{
          height: 26, padding: "0 10px", borderRadius: "var(--radius-pill)", cursor: canEdit ? "pointer" : "default",
          border: `1px solid color-mix(in srgb, ${aiColor} 30%, transparent)`,
          background: `color-mix(in srgb, ${aiColor} 10%, white)`, color: aiColor,
          fontSize: "var(--text-2xs)", fontWeight: 700, fontFamily: "var(--font-sans)",
        }}>{glyph}</button>
      )}
      {canEdit && !empty && !host && (
        <button onClick={onKick} aria-label="踢人" style={{
          width: 24, height: 24, borderRadius: "50%", border: "none", cursor: "pointer",
          background: "var(--surface-sunken)", color: "var(--text-tertiary)", fontSize: 13, lineHeight: 1,
        }}>✕</button>
      )}
    </div>
  );
}
