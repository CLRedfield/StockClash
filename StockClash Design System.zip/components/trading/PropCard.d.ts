import * as React from "react";

export interface PropCardProps {
  name: React.ReactNode;
  desc?: React.ReactNode;
  /** Effect family. @default "buff" */
  category?: "buff" | "info" | "pvp";
  icon?: React.ReactNode;
  /** Stack count (compact slot variant). @default 1 */
  count?: number;
  disabled?: boolean;
  /** Slot-bar variant (52px square). @default false */
  compact?: boolean;
  onUse?: () => void;
  style?: React.CSSProperties;
}

/** 道具 card — 增益 / 信息 / 搅局, full or compact slot variant. */
export function PropCard(props: PropCardProps): JSX.Element;
