import * as React from "react";

export interface StatTileProps {
  label: React.ReactNode;
  value: React.ReactNode;
  sub?: React.ReactNode;
  /** Tints the value. @default "neutral" */
  accent?: "neutral" | "up" | "down" | "warn" | "accent";
  /** Boxed inset treatment for hero metrics (净值). @default false */
  emphasis?: boolean;
  style?: React.CSSProperties;
}

/** HUD metric tile — 现金 / 持仓 / 负债 / 净值. Monospace tabular value. */
export function StatTile(props: StatTileProps): JSX.Element;
