import React from "react";

/**
 * Match countdown — mm:ss monospace with a thin progress track.
 * Turns to the warn/danger hue under the threshold seconds.
 */
export function Countdown({ remaining = 0, total = 240, size = "md", style = {}, ...rest }) {
  const m = Math.floor(Math.max(0, remaining) / 60);
  const s = Math.max(0, remaining) % 60;
  const txt = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  const frac = total ? Math.max(0, Math.min(1, remaining / total)) : 0;
  const danger = remaining <= 15;
  const warn = remaining <= 30 && !danger;
  const color = danger ? "var(--price-down)" : warn ? "var(--warn-500)" : "var(--text-primary)";
  const fontSizes = { sm: "var(--text-lg)", md: "var(--text-2xl)", lg: "var(--text-4xl)" };
  return (
    <div style={{ display: "inline-flex", flexDirection: "column", gap: 6, ...style }} {...rest}>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 7 }}>
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round"><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2.5 2.5M9 2h6" /></svg>
        <span style={{
          fontFamily: "var(--font-mono)", fontSize: fontSizes[size] || fontSizes.md,
          fontWeight: "var(--weight-bold)", fontVariantNumeric: "tabular-nums",
          letterSpacing: "var(--tracking-tight)", color, lineHeight: 1,
          animation: danger ? "sc-pulse 1s var(--ease-in-out) infinite" : "none",
        }}>{txt}</span>
      </div>
      <div style={{ height: 4, borderRadius: 99, background: "var(--surface-sunken)", overflow: "hidden", width: "100%", minWidth: 90 }}>
        <div style={{ height: "100%", width: `${frac * 100}%`, background: color, borderRadius: 99, transition: "width 1s linear" }} />
      </div>
      <style>{`@keyframes sc-pulse{0%,100%{opacity:1}50%{opacity:0.45}}`}</style>
    </div>
  );
}
