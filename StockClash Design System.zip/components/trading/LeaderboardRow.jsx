import React from "react";

const AI_TONE = { easy: "var(--slate-400)", normal: "var(--info-500)", hard: "var(--mkt-us)" };

/**
 * Live leaderboard row — rank, player, net worth, trend.
 * `you` highlights the current player; `ai` shows a difficulty chip.
 */
export function LeaderboardRow({ rank, name, net, deltaPct = 0, you = false, ai = null, broke = false, style = {}, ...rest }) {
  const dir = deltaPct > 0 ? "up" : deltaPct < 0 ? "down" : "flat";
  const dColor = dir === "up" ? "var(--price-up)" : dir === "down" ? "var(--price-down)" : "var(--price-flat)";
  const medal = rank === 1 ? "var(--gold-500)" : rank === 2 ? "var(--slate-400)" : rank === 3 ? "#c08a4a" : "var(--slate-300)";
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      height: 48, padding: "0 12px",
      borderRadius: "var(--radius-md)",
      background: you ? "var(--accent-soft)" : "transparent",
      border: `1px solid ${you ? "var(--accent-soft-border)" : "transparent"}`,
      opacity: broke ? 0.55 : 1,
      ...style,
    }} {...rest}>
      <span style={{
        width: 22, textAlign: "center", flexShrink: 0,
        fontFamily: "var(--font-mono)", fontSize: "var(--text-md)", fontWeight: "var(--weight-bold)",
        color: rank <= 3 ? medal : "var(--text-tertiary)",
      }}>{rank}</span>
      <span style={{
        width: 30, height: 30, borderRadius: "50%", flexShrink: 0,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        background: you ? "var(--accent)" : "var(--surface-sunken)",
        color: you ? "var(--on-accent)" : "var(--text-secondary)",
        fontSize: "var(--text-sm)", fontWeight: "var(--weight-bold)", fontFamily: "var(--font-display)",
      }}>{String(name || "").slice(0, 1)}</span>
      <div style={{ flex: 1, minWidth: 0, display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{
          fontSize: "var(--text-sm)", fontWeight: "var(--weight-semibold)", color: "var(--text-primary)",
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>{name}{you && <span style={{ color: "var(--accent-press)" }}> · 你</span>}</span>
        {ai && <span style={{
          fontSize: "var(--text-2xs)", fontWeight: "var(--weight-semibold)", padding: "1px 6px",
          borderRadius: "var(--radius-pill)", color: AI_TONE[ai] || AI_TONE.normal,
          background: `color-mix(in srgb, ${AI_TONE[ai] || AI_TONE.normal} 12%, white)`,
        }}>AI·{ai === "easy" ? "简" : ai === "hard" ? "难" : "普"}</span>}
        {broke && <span style={{ fontSize: "var(--text-2xs)", color: "var(--price-down)", fontWeight: 600 }}>破产</span>}
      </div>
      <div style={{ textAlign: "right", flexShrink: 0 }}>
        <div style={{
          fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", fontWeight: "var(--weight-bold)",
          fontVariantNumeric: "tabular-nums lining-nums", color: "var(--text-primary)", lineHeight: 1.2,
        }}>{net}</div>
        <div style={{
          fontFamily: "var(--font-mono)", fontSize: "var(--text-2xs)", fontWeight: "var(--weight-semibold)",
          color: dColor, lineHeight: 1.2,
        }}>{deltaPct > 0 ? "+" : ""}{deltaPct.toFixed(1)}%</div>
      </div>
    </div>
  );
}
