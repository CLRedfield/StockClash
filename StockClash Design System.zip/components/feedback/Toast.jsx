import React from "react";

const TONES = {
  info:    ["var(--info-500)", "var(--info-50)"],
  up:      ["var(--price-up)", "var(--price-up-soft)"],
  down:    ["var(--price-down)", "var(--price-down-soft)"],
  warn:    ["var(--warn-500)", "var(--warn-50)"],
  accent:  ["var(--accent-press)", "var(--accent-soft)"],
};

/**
 * Toast / fx notice — 成交飘字, 爆仓, 道具登场, 喊话. Self-contained pill.
 */
export function Toast({ children, tone = "info", icon = null, title, style = {}, ...rest }) {
  const [color, bg] = TONES[tone] || TONES.info;
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 10,
      padding: "10px 14px", minWidth: 200, maxWidth: 360,
      borderRadius: "var(--radius-md)",
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-lg)",
      ...style,
    }} {...rest}>
      <span style={{
        width: 30, height: 30, borderRadius: "var(--radius-sm)", flexShrink: 0,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        background: bg, color,
      }}>{icon}</span>
      <div style={{ minWidth: 0 }}>
        {title && <div style={{ fontSize: "var(--text-sm)", fontWeight: "var(--weight-semibold)", color: "var(--text-primary)" }}>{title}</div>}
        <div style={{ fontSize: "var(--text-xs)", color: "var(--text-secondary)", lineHeight: 1.4 }}>{children}</div>
      </div>
    </div>
  );
}
