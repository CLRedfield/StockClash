import React from "react";

/**
 * Centered modal dialog with scrim. Use for 贷款/还款 confirm, 结算, 破产, 被踢提示.
 */
export function Dialog({ open = true, title, children, footer = null, onClose, tone = "default", width = 420, style = {}, ...rest }) {
  if (!open) return null;
  const accentBar = {
    default: "var(--accent)",
    danger: "var(--price-down)",
    up: "var(--price-up)",
  }[tone] || "var(--accent)";
  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: "var(--z-modal)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
        background: "color-mix(in srgb, var(--slate-950) 38%, transparent)",
        backdropFilter: "var(--blur-overlay)",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        style={{
          width, maxWidth: "100%",
          background: "var(--surface-card)",
          borderRadius: "var(--radius-xl)",
          border: "1px solid var(--border-subtle)",
          boxShadow: "var(--shadow-lg)",
          overflow: "hidden",
          ...style,
        }}
        {...rest}
      >
        <div style={{ height: 3, background: accentBar }} />
        <div style={{ padding: "20px 22px" }}>
          {title && <h3 style={{ fontSize: "var(--text-lg)", marginBottom: 10 }}>{title}</h3>}
          <div style={{ fontSize: "var(--text-base)", color: "var(--text-secondary)", lineHeight: 1.6 }}>{children}</div>
        </div>
        {footer && (
          <div style={{
            display: "flex", justifyContent: "flex-end", gap: 10,
            padding: "14px 22px", borderTop: "1px solid var(--border-subtle)", background: "var(--surface-inset)",
          }}>{footer}</div>
        )}
      </div>
    </div>
  );
}
