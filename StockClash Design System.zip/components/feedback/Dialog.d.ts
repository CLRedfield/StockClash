import * as React from "react";

export interface DialogProps extends React.HTMLAttributes<HTMLDivElement> {
  open?: boolean;
  title?: React.ReactNode;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  onClose?: () => void;
  /** Top accent bar color. @default "default" */
  tone?: "default" | "danger" | "up";
  /** Dialog width in px. @default 420 */
  width?: number;
  style?: React.CSSProperties;
}

/** Centered modal with scrim — confirms, 结算, 破产, 被踢提示. */
export function Dialog(props: DialogProps): JSX.Element | null;
