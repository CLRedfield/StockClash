import * as React from "react";

export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  title?: React.ReactNode;
  /** @default "info" */
  tone?: "info" | "up" | "down" | "warn" | "accent";
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Toast / fx notice — 成交, 爆仓, 道具登场, 喊话. */
export function Toast(props: ToastProps): JSX.Element;
