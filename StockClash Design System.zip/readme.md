# 操盘杀 · StockClash — Design System

A light-theme design system for **《操盘杀 · StockClash》**, a real-time stock-trading speed-competition game. One match runs ~4 minutes and replays ~4 months of real historical price action; up to 4 players (humans + AI) trade the same live candle feed — long, short, leverage, loans — and the highest net worth at the bell wins. The product surfaces a **"trading-terminal" feel with a clean, game-friendly polish**.

This system is invented from the game design document (no prior codebase or visual brand existed). It is light, restrained, and terminal-clean: a **gold (金价金) accent**, **cool slate neutrals**, **green-up / red-down** P&L, geometric sans headings, and **monospace tabular numbers** on every value that ticks.

> 一局四分钟，跑完现实里四个月的行情。看谁是股神，谁在被割韭菜。

---

## Sources

| Source | Notes |
| --- | --- |
| `uploads/游戏设计文档.md` | The game design document — gameplay, economy (做多/做空/杠杆/贷款), rooms & multiplayer, **§7 界面与美术** (visual direction & wireframes), tech stack, milestones. The single source of truth for this system. |
| `道具图鉴.md`, `README.md` | Referenced by the doc but **not provided**. The props (道具) names/effects here are taken from §8 examples; full item table lives in `道具图鉴.md` (unseen). |
| `hearthStoneKill2` | Referenced as the netcode/room-management lineage (MQTT host-authoritative, kick/swap/AI seats). **Code not provided** — it only informs interaction concepts (room seats, host controls), not visuals. |

**No Figma, no screenshots, no codebase were attached.** All visuals are an original interpretation of the written direction. The user chose: light theme · gold accent · 绿涨红跌 · geometric sans + mono digits · 中文 UI · restrained thin-stroke cards · 3 trading-screen layout variants.

> ⚠️ **Font substitution flag:** there was no brand font. The system uses Google Fonts — **Space Grotesk** (Latin display), **Noto Sans SC** (Chinese), **JetBrains Mono** (numbers) — loaded via CDN in `tokens/fonts.css`. Swap for self-hosted files when you have brand fonts.

---

## CONTENT FUNDAMENTALS — how copy is written

- **Language:** Simplified Chinese, first. English appears only as the wordmark (StockClash), market/data shorthand, and code tokens.
- **Voice:** punchy, gamer-room energy with finance slang — confident and a little cheeky. Headlines read like trash-talk ("看谁是股神，谁在被割韭菜"); body copy stays plain and instructional.
- **Person:** addresses the player as **你**; the player's own seat/row is literally labelled **你**. System/host actions are stated neutrally ("房主点开始").
- **Numbers carry the message.** Prices, %, ¥ amounts and timers do the talking — keep surrounding words minimal. Always group thousands and show sign (`+3.21%`, `-1.84%`, `¥132,400`).
- **Casing:** Chinese needs none; Latin eyebrows/labels are UPPERCASE with wide tracking (现金 → "CASH" style eyebrows are uppercased only when Latin). Tier/badge labels are short nouns (闪电 / 标准 ★ / 长局).
- **Terminology (keep consistent):** 做多/买入, 做空, 平多/卖出, 平空, 贷款/还款, 净值, 爆仓, 强平, 盲盒, 道具, 房主, 补位(AI), 档位, K线来源.
- **Punctuation & symbols:** use full-width Chinese punctuation in prose. Direction glyphs ▲ ▼ — for price; ★ marks the default 标准 tier; ♛ marks 房主.
- **Emoji:** **none.** Iconography is Lucide; status is shown with color + small icons, never emoji.
- **Tone guardrails:** every screen carries the disclaimer that history is for entertainment and not investment advice. Don't imply real trading.
- **Example microcopy:** "放款即计 +2% 利息，之后每 30 秒复利。欠债期间不能再次贷款。" · "保证金不足，空头被强平" · "获得「内幕消息」" · "本局股神".

---

## VISUAL FOUNDATIONS

**Overall vibe.** A *light* trading terminal: white cards on a cool off-white app background, hairline borders, dense but breathable numeric panels. Premium-but-fast — gold is the only saturated brand color; everything else is slate + the green/red P&L pair + four market hues.

- **Color.** Accent = **金价金 `--gold-500 #c8932a`** (buttons, links, active, brand) with dark ink (`--on-accent #1a1205`) on top for a premium read. Neutrals are **cool slate** (`--slate-50` app bg, `#fff` cards, `--slate-150/200` borders, `--slate-900` text). **绿涨红跌**: gains `--price-up #0a8f59`, losses `--price-down #e5484d`, each with a soft tint + hairline border for chips. Four market categories have their own hues: 大A red, 港股 blue, 美股 indigo, 虚拟货币 bitcoin-orange — used only as category identity, never for P&L.
- **Type.** Display/headings **Space Grotesk + Noto Sans SC**, 700, tight tracking. Body **Noto Sans SC**, 400/600. **All ticking numbers** (price, 净值, timer, P&L) use **JetBrains Mono** with `tabular-nums lining-nums` (`.sc-num`) so digits don't jitter as they update. Eyebrows/labels: 11px, 600, uppercase, 0.08em.
- **Spacing & layout.** 4px grid (`--space-*`). Content is centered in max-width containers (room 980, trading 1080–1280). Trade HUD is a horizontal strip of `StatTile`s; the leaderboard is a fixed right rail (or left rail in the dense layout). Primary actions are ≥48px (touch). The game is responsive down to phone-portrait per the doc.
- **Backgrounds.** Mostly flat `--surface-app` / white cards. **No photographic imagery, no full-bleed images** — this is a UI product, not a marketing site. The only "texture" is faint horizontal grid lines behind chart-heavy contexts and the candle/volume chart itself. The winner banner uses a single subtle gold→white linear wash; that's the only gradient in the system.
- **Cards.** Hairline border **leads** (`1px --border-subtle`), radius **lg (14)**, shadow is a soft low *lift* (`--shadow-card/md`), never a heavy drop. `tone="sunken"` insets panels; `glow` adds a restrained gold ring for one hero panel only.
- **Borders.** 1px hairlines everywhere; `--border-strong` for inputs/segmented; dashed `--border-strong` for empty seats / empty prop slots.
- **Shadows / elevation.** `--shadow-card` (resting) → `--shadow-md` (raised) → `--shadow-lg` (modal). `--glow-gold` reserved for the primary CTA / winner. Up/down glows exist for fx (爆仓 flash) but are used sparingly.
- **Corner radii.** sm 6 (inputs), md 10 (buttons), lg 14 (cards), xl 20 (modals/hero), pill (chips, badges, switches, source chips).
- **Animation & motion.** Quick and crisp: `--ease-out` for UI, `--dur-fast 140ms` hovers, `--dur-base 220ms` toggles. Reserved bounce `--ease-pop` only for **fx** (trade pops, 道具登场, 爆仓). The countdown pulses under 15s. No infinite decorative loops on layout.
- **Hover / press.** Buttons: hover = `brightness(0.96)`, press = `translateY(1px) scale(0.985)`. Icon buttons: hover fills with `--surface-sunken`. Cards/entry tiles: hover lifts `translateY(-3px)` + shadow upgrade. Links: gold-700, underline on hover.
- **Transparency & blur.** Used sparingly — sticky toolbar and modal scrims use `backdrop-filter: blur(8px)` over a translucent surface. No glassmorphism on content cards (the user chose restrained over glass).
- **Imagery color vibe.** N/A (no photography). Charts are clean two-color (green/red) on white; volume bars at 35% opacity.

---

## ICONOGRAPHY

- **Set:** **[Lucide](https://lucide.dev)** (MIT) — 2px stroke, 24px grid, rounded caps/joins. Matches the geometric-sans, terminal-clean character.
- **Delivery:** loaded from CDN (`unpkg.com/lucide`) in the UI kit and the iconography card; a small React `<Icon name="…">` wrapper (in `ui_kits/stockclash/lib.jsx`) renders real Lucide SVGs. **For production, self-host the `lucide` npm package.** This is the nearest-match substitution since no brand icon set existed — flagged here.
- **No icon font, no sprite, no PNG icons, no emoji, no unicode-as-icon** (except the three semantic glyphs ▲▼— for price direction, ★ for default tier, ♛ for host — these are typographic marks, not the icon system).
- **Color:** icons inherit `currentColor` — tertiary slate by default; trade-action icons take the up/down hue from context (买入 green, 做空 red); accent gold for emphasis.
- **Common glyphs:** `trending-up/down` (long/short), `wallet` (现金), `hand-coins` (贷款), `percent` (利率), `timer` (倒计时), `trophy` (排行/股神), `users` (座位), `eye/shield/snowflake/zap` (道具), `play/pause/rotate-ccw` (回放控制), `sliders-horizontal` (规则), `log-in` (加入).

---

## INDEX / Manifest

**Root**
- `styles.css` — global entry; `@import`-only. Consumers link this one file.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill front-matter for use in Claude Code.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `base.css`.

**Components** (`components/<group>/`) — `window.StockClashDesignSystem_2f48a1.<Name>`
- `core/` — **Button**, **IconButton**, **Card**, **Badge**
- `forms/` — **SegmentedControl**, **SourceChip**, **Switch**, **NumberStepper**
- `trading/` — **PriceTag**, **StatTile**, **LeaderboardRow**, **Countdown**, **SeatTile**, **PropCard**
- `feedback/` — **Dialog**, **Toast**

**Foundation cards** (`guidelines/*.html`) — Colors (brand / neutral / semantic / markets), Type (display / body / mono), Spacing (scale / radius / shadows), Brand (wordmark / iconography).

**UI kit** (`ui_kits/stockclash/`) — interactive click-through prototype: `index.html` (entry) → `Home` (大厅) → `Room` (房间) → `Trading` (交易, **3 layout variants**: 经典终端 / 聚焦操作 / 数据密集) → `Settlement` (结算). Supporting: `lib.jsx` (icons/helpers/data), `Chart.jsx` (candlestick), `App.jsx` (routing).

**Namespace:** `StockClashDesignSystem_2f48a1` — `const { Button } = window.StockClashDesignSystem_2f48a1`.
