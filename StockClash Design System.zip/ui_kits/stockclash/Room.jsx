/* StockClash UI kit — Room / 房间 (统一房间视图). Host config + seats. */
const { Button, Card, Badge, SegmentedControl, SourceChip, Switch, SeatTile } = window.StockClashDesignSystem_2f48a1;

function Room({ online = true, onStart, onLeave }) {
  const [src, setSrc] = React.useState({ cn: true, hk: true, us: false, crypto: true });
  const [tier, setTier] = React.useState("std");
  const [blind, setBlind] = React.useState(online);
  const [items, setItems] = React.useState(true);
  const [freeSwap, setFreeSwap] = React.useState(true);
  const [seats, setSeats] = React.useState([
    { seat: 1, type: "human", name: "你", host: true, you: true },
    { seat: 2, type: "human", name: "听雪" },
    { seat: 3, type: "human", name: "青锋" },
    { seat: 4, type: "ai", ai: "normal" },
    { seat: 5, type: "ai", ai: "hard" },
    { seat: 6, type: "empty" },
  ]);
  const cycleAi = (i) => setSeats(s => s.map((x, j) => j === i ? { ...x, ai: x.ai === "easy" ? "normal" : x.ai === "normal" ? "hard" : "easy" } : x));
  const kick = (i) => setSeats(s => s.map((x, j) => j === i ? { seat: x.seat, type: "empty" } : x));
  const filled = seats.filter(s => s.type !== "empty").length;

  const RuleChip = ({ icon, label, value }) => (
    <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", background: "var(--surface-inset)", border: "1px solid var(--border-subtle)", borderRadius: "var(--radius-md)" }}>
      <window.Icon name={icon} size={15} color="var(--text-tertiary)" />
      <span style={{ fontSize: "var(--text-xs)", color: "var(--text-tertiary)" }}>{label}</span>
      <span style={{ fontSize: "var(--text-sm)", fontWeight: 600, color: "var(--text-primary)", fontFamily: "var(--font-mono)" }}>{value}</span>
    </div>
  );

  return (
    <div style={{ maxWidth: 980, margin: "0 auto", padding: "28px 24px 40px" }}>
      {/* header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 22, flexWrap: "wrap", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <window.Wordmark size={22} />
          <Badge tone={online ? "info" : "neutral"} dot>{online ? "联机房间" : "本地房间"}</Badge>
        </div>
        {online && (
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: "var(--text-sm)", color: "var(--text-secondary)" }}>房间号</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xl)", fontWeight: 700, letterSpacing: "0.12em", color: "var(--accent-press)" }}>ABC123</span>
            <Button variant="secondary" size="sm" iconLeft={<window.Icon name="copy" size={14} />}>复制邀请</Button>
          </div>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* left: rules */}
        <Card header={<span style={{ display: "flex", alignItems: "center", gap: 8 }}><window.Icon name="sliders-horizontal" size={16} color="var(--accent-press)" />规则配置</span>} padding="18px">
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <p style={{ fontSize: "var(--text-2xs)", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-tertiary)", marginBottom: 9 }}>K 线来源（多选）</p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {Object.keys(window.MARKETS).map(m => (
                  <SourceChip key={m} market={m} label={window.MARKETS[m].label} checked={src[m]} onChange={(v) => setSrc({ ...src, [m]: v })} />
                ))}
              </div>
            </div>
            <div>
              <p style={{ fontSize: "var(--text-2xs)", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-tertiary)", marginBottom: 9 }}>档位</p>
              <SegmentedControl value={tier} onChange={setTier} options={window.TIERS.map(t => ({ value: t.value, label: t.label, star: t.star }))} />
              <p style={{ fontSize: "var(--text-xs)", color: "var(--text-secondary)", marginTop: 8 }}>
                {window.TIERS.find(t => t.value === tier).dur} 局时长 · 覆盖 {window.TIERS.find(t => t.value === tier).win} 真实行情 · 每 1s 刷新
              </p>
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              <RuleChip icon="wallet" label="初始资金" value="¥100k" />
              <RuleChip icon="receipt" label="手续费" value="标准" />
              <RuleChip icon="percent" label="贷款" value="+2% / 30s" />
            </div>
            <div style={{ display: "flex", gap: 20, paddingTop: 4 }}>
              <label style={{ display: "flex", alignItems: "center", gap: 9, fontSize: "var(--text-sm)", color: "var(--text-secondary)", cursor: "pointer" }}>
                <Switch checked={blind} onChange={setBlind} /> 盲盒模式
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: 9, fontSize: "var(--text-sm)", color: "var(--text-secondary)", cursor: "pointer" }}>
                <Switch checked={items} onChange={setItems} /> 道具模式 <span style={{ color: "var(--text-tertiary)", fontFamily: "var(--font-mono)" }}>60s</span>
              </label>
            </div>
          </div>
        </Card>

        {/* right: seats */}
        <Card header={<span style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%" }}><span style={{ display: "flex", alignItems: "center", gap: 8 }}><window.Icon name="users" size={16} color="var(--accent-press)" />座位</span><Badge tone="neutral">{filled}/6</Badge></span>} padding="18px">
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 9 }}>
            {seats.map((s, i) => (
              <SeatTile key={i} {...s} canEdit onKick={() => kick(i)} onCycleAi={() => cycleAi(i)} />
            ))}
          </div>
          <label style={{ display: "flex", alignItems: "center", gap: 9, fontSize: "var(--text-sm)", color: "var(--text-secondary)", cursor: "pointer", marginTop: 14 }}>
            <Switch checked={freeSwap} onChange={setFreeSwap} /> 允许玩家自由申请换座
          </label>
        </Card>
      </div>

      <div style={{ display: "flex", gap: 12, marginTop: 20, justifyContent: "flex-end" }}>
        <Button variant="secondary" size="lg" onClick={onLeave}>退出</Button>
        <Button variant="primary" size="lg" iconLeft={<window.Icon name="play" size={18} />} onClick={onStart}>开始游戏</Button>
      </div>
    </div>
  );
}
window.Room = Room;
