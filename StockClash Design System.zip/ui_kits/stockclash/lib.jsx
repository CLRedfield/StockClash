/* StockClash UI kit — shared helpers, fake data, Lucide icon wrapper.
   Loaded as a babel script; everything attaches to window for sibling screens. */

// ---- Lucide icon wrapper (real icons, CDN-loaded) ----
function Icon({ name, size = 18, stroke = 2, color = "currentColor", style = {} }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = `<i data-lucide="${name}"></i>`;
      window.lucide.createIcons({ nameAttr: "data-lucide", attrs: { width: size, height: size, "stroke-width": stroke } });
    }
  });
  return <span ref={ref} style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: size, height: size, color, ...style }} />;
}

// ---- Formatting ----
const yuan = (n) => "¥" + Math.round(n).toLocaleString("en-US");
const pct = (n) => (n > 0 ? "+" : "") + n.toFixed(2) + "%";

// ---- Seeded RNG (mulberry32) for reproducible candles ----
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Generate a believable OHLC series with a trend + volatility
function genCandles(seed = 7, n = 84, start = 100, drift = 0.004, vol = 0.018) {
  const r = rng(seed);
  const out = [];
  let prev = start;
  for (let i = 0; i < n; i++) {
    const wobble = (r() - 0.5) * 2;
    const trend = drift * (1 + Math.sin(i / 11));
    const o = prev;
    const c = Math.max(2, o * (1 + trend + wobble * vol));
    const hi = Math.max(o, c) * (1 + r() * vol * 0.8);
    const lo = Math.min(o, c) * (1 - r() * vol * 0.8);
    out.push({ o, h: hi, l: lo, c, v: 0.3 + r() });
    prev = c;
  }
  return out;
}

// ---- Markets & instruments ----
const MARKETS = {
  cn:     { id: "cn", label: "大 A", color: "var(--mkt-cn)" },
  hk:     { id: "hk", label: "港股", color: "var(--mkt-hk)" },
  us:     { id: "us", label: "美股", color: "var(--mkt-us)" },
  crypto: { id: "crypto", label: "虚拟货币", color: "var(--mkt-crypto)" },
};

const TIERS = [
  { value: "fast", label: "闪电", dur: "2 min", win: "2 个月" },
  { value: "std", label: "标准", star: true, dur: "4 min", win: "4 个月" },
  { value: "long", label: "长局", dur: "8 min", win: "1 年" },
  { value: "custom", label: "自定义", dur: "1–15 min", win: "1 周–3 年" },
];

// ---- Players (leaderboard / seats) ----
const PLAYERS = [
  { id: "you", name: "你", you: true, host: true, ai: null },
  { id: "p2", name: "听雪", ai: null },
  { id: "p3", name: "北辰", ai: "hard" },
  { id: "p4", name: "青锋", ai: "easy" },
  { id: "p5", name: "墨白", ai: "normal" },
];

// ---- Props (道具) ----
const PROPS = [
  { id: "insider", name: "内幕消息", category: "info", icon: "eye", desc: "看未来 3 tick 的方向" },
  { id: "swan", name: "黑天鹅", category: "pvp", icon: "bird", desc: "向对手砸盘一次" },
  { id: "free", name: "免单券", category: "buff", icon: "ticket", desc: "本笔交易免手续费" },
  { id: "shield", name: "止损盾", category: "buff", icon: "shield", desc: "免疫一次爆仓" },
  { id: "hike", name: "加息冲击", category: "pvp", icon: "trending-up", desc: "抬高对手贷款利率" },
  { id: "freeze", name: "冻结", category: "pvp", icon: "snowflake", desc: "对手数秒不能交易" },
  { id: "dip", name: "抄底券", category: "buff", icon: "anchor", desc: "双倍杠杆一次" },
];

// ---- Brand wordmark (typographic logo) ----
function Wordmark({ size = 28, stacked = false, mono = false }) {
  const gold = mono ? "currentColor" : "var(--accent)";
  return (
    <span style={{ display: "inline-flex", alignItems: stacked ? "flex-start" : "baseline", flexDirection: stacked ? "column" : "row", gap: stacked ? 2 : 9, lineHeight: 1 }}>
      <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: size, letterSpacing: "0.04em", color: "var(--text-primary)", display: "inline-flex", alignItems: "center", gap: 2 }}>
        操<span style={{ color: gold }}>盘</span>杀
      </span>
      <span style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: size * 0.5, letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--text-tertiary)" }}>
        StockClash
      </span>
    </span>
  );
}

Object.assign(window, { Icon, yuan, pct, rng, genCandles, MARKETS, TIERS, PLAYERS, PROPS, Wordmark });
