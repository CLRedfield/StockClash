/* StockClash UI kit — Home / 大厅. Three entry points. */
const { Button, Card, Badge } = window.StockClashDesignSystem_2f48a1;

function Home({ onCreate, onJoin }) {
  const entries = [
    { id: "local", icon: "monitor", title: "本地创建房间", sub: "1 名真人 + AI，无需联网", tone: "secondary" },
    { id: "online", icon: "wifi", title: "联机创建房间", sub: "生成 6 位房间号，开黑连打", tone: "primary" },
    { id: "join", icon: "log-in", title: "加入房间", sub: "输入房间号加入好友", tone: "secondary" },
  ];
  return (
    <div style={{ minHeight: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "48px 24px", gap: 40 }}>
      <div style={{ textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: 18 }}>
        <window.Wordmark size={44} />
        <p style={{ fontSize: "var(--text-lg)", color: "var(--text-secondary)", maxWidth: 460, lineHeight: 1.6 }}>
          一局四分钟，跑完现实里四个月的行情。<br />看谁是股神，谁在被割韭菜。
        </p>
        <div style={{ display: "flex", gap: 8 }}>
          <Badge tone="up" dot>实时 K 线</Badge>
          <Badge tone="accent">做多做空 · 杠杆</Badge>
          <Badge tone="info">4 人同台</Badge>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 240px)", gap: 16, maxWidth: "100%" }}>
        {entries.map((e) => (
          <button key={e.id} onClick={() => (e.id === "join" ? onJoin() : onCreate(e.id))}
            style={{
              textAlign: "left", cursor: "pointer", background: "var(--surface-card)",
              border: `1px solid ${e.tone === "primary" ? "var(--accent-soft-border)" : "var(--border-default)"}`,
              boxShadow: e.tone === "primary" ? "var(--glow-gold)" : "var(--shadow-card)",
              borderRadius: "var(--radius-xl)", padding: 22, display: "flex", flexDirection: "column", gap: 14,
              transition: "transform var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)",
            }}
            onMouseEnter={(ev) => { ev.currentTarget.style.transform = "translateY(-3px)"; ev.currentTarget.style.boxShadow = "var(--shadow-lg)"; }}
            onMouseLeave={(ev) => { ev.currentTarget.style.transform = ""; ev.currentTarget.style.boxShadow = e.tone === "primary" ? "var(--glow-gold)" : "var(--shadow-card)"; }}
          >
            <span style={{
              width: 46, height: 46, borderRadius: "var(--radius-md)",
              background: e.tone === "primary" ? "var(--accent)" : "var(--surface-sunken)",
              color: e.tone === "primary" ? "var(--on-accent)" : "var(--accent-press)",
              display: "inline-flex", alignItems: "center", justifyContent: "center",
            }}>
              <window.Icon name={e.icon} size={24} />
            </span>
            <div>
              <div style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-lg)", fontWeight: 700, color: "var(--text-primary)" }}>{e.title}</div>
              <div style={{ fontSize: "var(--text-sm)", color: "var(--text-secondary)", marginTop: 4 }}>{e.sub}</div>
            </div>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: "var(--text-sm)", fontWeight: 600, color: e.tone === "primary" ? "var(--accent-press)" : "var(--text-tertiary)", marginTop: 2 }}>
              进入 <window.Icon name="chevron-right" size={15} />
            </span>
          </button>
        ))}
      </div>

      <p style={{ fontSize: "var(--text-xs)", color: "var(--text-tertiary)", textAlign: "center" }}>
        历史行情仅作游戏化娱乐用途，费率/利率为可调平衡数值，不构成任何投资建议。
      </p>
    </div>
  );
}
window.Home = Home;
