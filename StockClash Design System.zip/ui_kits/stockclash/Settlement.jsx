/* StockClash UI kit — Settlement / 结算. Final ranking + 净值曲线复盘. */
const { Button, Card, Badge, StatTile, LeaderboardRow } = window.StockClashDesignSystem_2f48a1;

function NetCurve({ seed, color, width = 560, height = 150 }) {
  const r = window.rng(seed);
  const n = 60;
  const pts = [];
  let v = 100000;
  for (let i = 0; i < n; i++) { v = Math.max(20000, v * (1 + (r() - 0.46) * 0.06)); pts.push(v); }
  const hi = Math.max(...pts), lo = Math.min(...pts), rng_ = hi - lo || 1;
  const x = (i) => 6 + i * ((width - 12) / (n - 1));
  const y = (p) => 8 + (1 - (p - lo) / rng_) * (height - 16);
  const d = pts.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)} ${y(p).toFixed(1)}`).join(" ");
  const area = `${d} L${x(n - 1).toFixed(1)} ${height - 8} L6 ${height - 8} Z`;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} style={{ display: "block" }}>
      <defs><linearGradient id={"g" + seed} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={color} stopOpacity="0.18" /><stop offset="100%" stopColor={color} stopOpacity="0" />
      </linearGradient></defs>
      <line x1="6" y1={y(100000)} x2={width - 6} y2={y(100000)} stroke="var(--border-strong)" strokeDasharray="3 3" strokeWidth="1" />
      <path d={area} fill={`url(#g${seed})`} />
      <path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function Settlement({ onAgain, onRoom }) {
  const finals = [
    { id: "you", name: "你", net: 132400, ret: 32.4, dd: 11.2, trades: 18, ai: null, you: true },
    { id: "p2", name: "听雪", net: 119000, ret: 19.0, dd: 14.0, trades: 22, ai: null },
    { id: "p5", name: "墨白", net: 104300, ret: 4.3, dd: 9.5, trades: 12, ai: "normal" },
    { id: "p3", name: "北辰", net: 98200, ret: -1.8, dd: 22.0, trades: 31, ai: "hard" },
    { id: "p4", name: "青锋", net: 0, ret: -100, dd: 100, trades: 9, ai: "easy" },
  ];
  const winner = finals[0];
  return (
    <div style={{ maxWidth: 1080, margin: "0 auto", padding: "26px 24px 40px" }}>
      {/* winner banner */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 20, padding: "18px 22px", borderRadius: "var(--radius-xl)", background: "linear-gradient(100deg, var(--gold-50), var(--surface-card))", border: "1px solid var(--accent-soft-border)", boxShadow: "var(--glow-gold)" }}>
        <span style={{ width: 52, height: 52, borderRadius: "50%", background: "var(--accent)", color: "var(--on-accent)", display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
          <window.Icon name="trophy" size={26} />
        </span>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: "var(--text-xs)", letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--text-tertiary)", fontWeight: 600 }}>本局股神</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-2xl)", fontWeight: 700, color: "var(--text-primary)" }}>{winner.name} · 你</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-3xl)", fontWeight: 700, color: "var(--price-up)", letterSpacing: "-0.02em" }}>{window.yuan(winner.net)}</div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", fontWeight: 600, color: "var(--price-up)" }}>{window.pct(winner.ret)} 收益率</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 16, alignItems: "start" }}>
        {/* curve + reveal */}
        <Card header={<span style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%" }}><span style={{ display: "flex", alignItems: "center", gap: 8 }}><window.Icon name="activity" size={16} color="var(--accent-press)" />净值曲线复盘</span><Badge tone="cn" dot>贵州茅台 · 2021-06 → 10</Badge></span>} padding="16px">
          <NetCurve seed={3} color="var(--price-up)" />
          <div style={{ display: "flex", gap: 22, marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--border-subtle)" }}>
            <StatTile label="收益率" value={window.pct(winner.ret)} accent="up" />
            <StatTile label="最大回撤" value={winner.dd.toFixed(1) + "%"} accent="down" />
            <StatTile label="交易次数" value={winner.trades} />
            <StatTile label="盲盒揭晓" value="贵州茅台" accent="accent" />
          </div>
        </Card>

        {/* ranking */}
        <Card header={<span style={{ display: "flex", alignItems: "center", gap: 8 }}><window.Icon name="list-ordered" size={16} color="var(--accent-press)" />最终排名</span>} padding="12px">
          {finals.map((f, i) => (
            <div key={f.id} style={{ borderBottom: i < finals.length - 1 ? "1px solid var(--border-subtle)" : "none" }}>
              <LeaderboardRow rank={i + 1} name={f.name} net={window.yuan(f.net)} deltaPct={f.ret} you={f.you} ai={f.ai} broke={f.net <= 0} />
            </div>
          ))}
        </Card>
      </div>

      <div style={{ display: "flex", gap: 12, marginTop: 20, justifyContent: "center" }}>
        <Button variant="secondary" size="lg" iconLeft={<window.Icon name="users" size={18} />} onClick={onRoom}>回到房间</Button>
        <Button variant="primary" size="lg" iconLeft={<window.Icon name="rotate-ccw" size={18} />} onClick={onAgain}>再来一局</Button>
      </div>
    </div>
  );
}
window.Settlement = Settlement;
