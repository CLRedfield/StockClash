/* StockClash UI kit — App shell: routing + demo chrome. */
const { Badge, SegmentedControl } = window.StockClashDesignSystem_2f48a1;

function App() {
  const [screen, setScreen] = React.useState("home");
  const [online, setOnline] = React.useState(true);
  const [variant, setVariant] = React.useState("classic");
  const candles = React.useMemo(() => window.genCandles(7, 84, 100, 0.006, 0.02), []);

  const screens = [
    { id: "home", label: "大厅" },
    { id: "room", label: "房间" },
    { id: "trade", label: "交易" },
    { id: "settle", label: "结算" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "var(--surface-app)", display: "flex", flexDirection: "column" }}>
      {/* demo toolbar */}
      <div style={{ position: "sticky", top: 0, zIndex: 50, height: 54, flexShrink: 0, display: "flex", alignItems: "center", gap: 16, padding: "0 18px", background: "color-mix(in srgb, var(--surface-card) 88%, transparent)", backdropFilter: "blur(8px)", borderBottom: "1px solid var(--border-subtle)" }}>
        <window.Wordmark size={18} />
        <div style={{ width: 1, height: 22, background: "var(--border-default)" }} />
        <div style={{ display: "flex", gap: 4 }}>
          {screens.map(s => (
            <button key={s.id} onClick={() => setScreen(s.id)} style={{
              height: 32, padding: "0 14px", borderRadius: "var(--radius-sm)", border: "none", cursor: "pointer",
              fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", fontWeight: 600,
              color: screen === s.id ? "var(--text-primary)" : "var(--text-tertiary)",
              background: screen === s.id ? "var(--surface-sunken)" : "transparent",
            }}>{s.label}</button>
          ))}
        </div>
        <div style={{ flex: 1 }} />
        {screen === "trade" && (
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: "var(--text-xs)", color: "var(--text-tertiary)" }}>布局</span>
            <SegmentedControl size="sm" value={variant} onChange={setVariant} options={[
              { value: "classic", label: "经典终端" }, { value: "focus", label: "聚焦操作" }, { value: "dense", label: "数据密集" }]} />
          </div>
        )}
      </div>

      <div style={{ flex: 1 }}>
        {screen === "home" && <window.Home onCreate={(m) => { setOnline(m === "online"); setScreen("room"); }} onJoin={() => { setOnline(true); setScreen("room"); }} />}
        {screen === "room" && <window.Room online={online} onStart={() => setScreen("trade")} onLeave={() => setScreen("home")} />}
        {screen === "trade" && <window.Trading variant={variant} candles={candles} onSettle={() => setScreen("settle")} onLoan={() => {}} />}
        {screen === "settle" && <window.Settlement onAgain={() => setScreen("trade")} onRoom={() => setScreen("room")} />}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
