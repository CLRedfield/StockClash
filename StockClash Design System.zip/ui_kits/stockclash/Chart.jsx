/* StockClash UI kit — lightweight SVG candlestick chart with volume subchart.
   Pure data-viz from generated OHLC. Green up / red down. */

function CandleChart({ candles, revealed, width = 640, height = 320, showVolume = true }) {
  const data = candles.slice(0, revealed);
  const padL = 8, padR = 54, padT = 10, padB = 6;
  const volH = showVolume ? Math.round(height * 0.18) : 0;
  const gap = showVolume ? 8 : 0;
  const priceH = height - volH - gap - padT - padB;
  const plotW = width - padL - padR;

  const all = candles; // scale to the full series so axis is stable as it reveals
  const hi = Math.max(...all.map(c => c.h));
  const lo = Math.min(...all.map(c => c.l));
  const range = hi - lo || 1;
  const x = (i) => padL + (i + 0.5) * (plotW / all.length);
  const y = (p) => padT + (1 - (p - lo) / range) * priceH;
  const cw = Math.max(2, (plotW / all.length) * 0.62);

  const upC = "var(--price-up)", downC = "var(--price-down)";
  const last = data[data.length - 1];
  const lastY = last ? y(last.c) : 0;
  const lastUp = last ? last.c >= last.o : true;

  const maxV = Math.max(...all.map(c => c.v));
  const volY0 = padT + priceH + gap;

  // gridlines
  const lines = [0, 0.25, 0.5, 0.75, 1].map(f => {
    const p = lo + range * f;
    return { y: y(p), label: p.toFixed(1) };
  });

  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height="100%" style={{ display: "block", fontFamily: "var(--font-mono)" }}>
      {/* grid */}
      {lines.map((l, i) => (
        <g key={i}>
          <line x1={padL} y1={l.y} x2={padL + plotW} y2={l.y} stroke="var(--border-subtle)" strokeWidth="1" strokeDasharray="2 4" />
          <text x={width - padR + 6} y={l.y + 3} fontSize="9" fill="var(--text-tertiary)">{l.label}</text>
        </g>
      ))}
      {/* candles */}
      {data.map((c, i) => {
        const up = c.c >= c.o;
        const col = up ? upC : downC;
        const oy = y(c.o), cy = y(c.c);
        const top = Math.min(oy, cy);
        const bh = Math.max(1.5, Math.abs(cy - oy));
        return (
          <g key={i}>
            <line x1={x(i)} y1={y(c.h)} x2={x(i)} y2={y(c.l)} stroke={col} strokeWidth="1" />
            <rect x={x(i) - cw / 2} y={top} width={cw} height={bh} fill={col} rx="0.5" />
            {showVolume && (
              <rect x={x(i) - cw / 2} y={volY0 + volH - (c.v / maxV) * volH} width={cw} height={(c.v / maxV) * volH}
                fill={col} opacity="0.35" />
            )}
          </g>
        );
      })}
      {/* last price marker */}
      {last && (
        <g>
          <line x1={padL} y1={lastY} x2={padL + plotW} y2={lastY} stroke={lastUp ? upC : downC} strokeWidth="1" strokeDasharray="3 3" opacity="0.7" />
          <rect x={width - padR} y={lastY - 8} width={padR - 2} height="16" rx="3" fill={lastUp ? upC : downC} />
          <text x={width - padR / 2 - 1} y={lastY + 3} fontSize="9.5" fontWeight="700" fill="#fff" textAnchor="middle">{last.c.toFixed(2)}</text>
        </g>
      )}
    </svg>
  );
}

window.CandleChart = CandleChart;
