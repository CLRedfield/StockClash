/* StockClash UI kit — Trading / 交易主界面. Three layout variants share these pieces. */
const { Button, Card, Badge, PriceTag, StatTile, LeaderboardRow, Countdown, PropCard, SegmentedControl, NumberStepper, IconButton } = window.StockClashDesignSystem_2f48a1;

// ---------- shared sub-pieces ----------
function InstrumentHead({ name, candle, prevClose, blind, big }) {
  const changePct = ((candle.c - prevClose) / prevClose) * 100;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: big ? "var(--text-xl)" : "var(--text-lg)", fontWeight: 700, color: "var(--text-primary)" }}>{blind ? "标的 A" : name}</span>
          {blind ? <Badge tone="warn" dot>盲盒</Badge> : <Badge tone="cn">大 A</Badge>}
        </div>
        {!blind && <span style={{ fontSize: "var(--text-xs)", color: "var(--text-tertiary)" }}>SH600519 · 日 K 加速回放</span>}
      </div>
      <PriceTag price={candle.c} changePct={changePct} size={big ? "lg" : "md"} />
    </div>
  );
}

function HUD({ pf, compact }) {
  return (
    <div style={{ display: "flex", gap: compact ? 16 : 22, flexWrap: "wrap", alignItems: "center" }}>
      <StatTile label="现金" value={window.yuan(pf.cash)} />
      <StatTile label="持仓" value={(pf.pos > 0 ? "+" : "") + pf.pos + " 股"} accent={pf.pos > 0 ? "up" : "neutral"} />
      <StatTile label="负债" value={window.yuan(pf.debt)} accent={pf.debt > 0 ? "warn" : "neutral"} />
      <StatTile label="净值" value={window.yuan(pf.net)} accent={pf.net >= 100000 ? "up" : "down"} sub={window.pct((pf.net - 100000) / 1000)} emphasis={!compact} />
    </div>
  );
}

function QuickAmount({ value, onChange }) {
  return <SegmentedControl size="sm" value={value} onChange={onChange} options={["25", "50", "100"].map(v => ({ value: v, label: v + "%" }))} />;
}

function TradeActions({ qty, setQty, pct, setPct, compact, onLoan }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
        <NumberStepper value={qty} step={10} unit="股" onChange={setQty} />
        <QuickAmount value={pct} onChange={setPct} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        <Button variant="up" size="lg" iconLeft={<window.Icon name="trending-up" size={17} />}>买入 / 做多</Button>
        <Button variant="down" size="lg" iconLeft={<window.Icon name="trending-down" size={17} />}>做空</Button>
        <Button variant="secondary" size="md">卖出 / 平多</Button>
        <Button variant="secondary" size="md">平空</Button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        <Button variant="ghost" size="md" iconLeft={<window.Icon name="hand-coins" size={16} />} onClick={onLoan} style={{ border: "1px solid var(--border-default)" }}>贷款</Button>
        <Button variant="ghost" size="md" iconLeft={<window.Icon name="undo-2" size={16} />} style={{ border: "1px solid var(--border-default)" }}>还款</Button>
      </div>
    </div>
  );
}

function Leaderboard({ rows, compact }) {
  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 12px 8px" }}>
        <span style={{ fontSize: "var(--text-2xs)", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-tertiary)" }}>实时排行榜</span>
        <window.Icon name="trophy" size={14} color="var(--accent)" />
      </div>
      {rows.map((r, i) => <LeaderboardRow key={r.id} rank={i + 1} name={r.name} net={window.yuan(r.net)} deltaPct={(r.net - 100000) / 1000} you={r.you} ai={r.ai} broke={r.net <= 0} />)}
    </div>
  );
}

function PropBar({ items }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <span style={{ fontSize: "var(--text-2xs)", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--text-tertiary)" }}>道具栏</span>
      <div style={{ display: "flex", gap: 8 }}>
        {items.map((p, i) => <PropCard key={i} compact category={p.category} name={p.name} icon={<window.Icon name={p.icon} size={20} />} count={p.count} onUse={() => {}} />)}
        {Array.from({ length: 3 - items.length }).map((_, i) => (
          <div key={"e" + i} style={{ width: 52, height: 52, borderRadius: "var(--radius-md)", border: "1.5px dashed var(--border-strong)", background: "var(--surface-inset)" }} />
        ))}
      </div>
    </div>
  );
}

// ---------- main ----------
function Trading({ variant = "classic", candles, onSettle, onLoan }) {
  const PERSIST = "sc_kit_revealed";
  const [revealed, setRevealed] = React.useState(() => {
    const s = parseInt(localStorage.getItem(PERSIST) || "", 10);
    return Number.isFinite(s) && s >= 30 && s <= candles.length ? s : 42;
  });
  const [playing, setPlaying] = React.useState(true);
  const [qty, setQty] = React.useState(120);
  const [pctSel, setPctSel] = React.useState("50");

  React.useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setRevealed(r => {
      const n = Math.min(candles.length, r + 1);
      localStorage.setItem(PERSIST, String(n));
      return n;
    }), 900);
    return () => clearInterval(t);
  }, [playing, candles.length]);

  const candle = candles[revealed - 1];
  const prevClose = candles[Math.max(0, revealed - 6)].c;
  const remaining = Math.max(0, Math.round((candles.length - revealed) / candles.length * 240));

  // fake portfolio driven by price
  const pos = 120;
  const cash = 82300;
  const net = Math.round(cash + pos * candle.c * 7.8);
  const pf = { cash, pos, debt: 0, net };

  // fake leaderboard, sorted
  const blind = false;
  const others = window.PLAYERS.map((p, i) => ({ ...p, net: p.you ? net : Math.round(net * (0.74 + 0.2 * Math.sin(revealed / 9 + i)) ) }));
  const rows = [...others].sort((a, b) => b.net - a.net);
  const myProps = [{ category: "info", name: "内幕消息", icon: "eye", count: 1 }, { category: "buff", name: "止损盾", icon: "shield", count: 2 }];

  const PlayCtl = () => (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <IconButton size="sm" variant="soft" label={playing ? "暂停" : "播放"} onClick={() => setPlaying(p => !p)}>
        <window.Icon name={playing ? "pause" : "play"} size={15} />
      </IconButton>
      <IconButton size="sm" variant="soft" label="重置" onClick={() => { setRevealed(42); localStorage.setItem(PERSIST, "42"); }}>
        <window.Icon name="rotate-ccw" size={15} />
      </IconButton>
    </div>
  );

  const chartCard = (h) => (
    <div style={{ background: "var(--surface-card)", border: "1px solid var(--border-subtle)", borderRadius: "var(--radius-lg)", padding: 10, height: h }}>
      <window.CandleChart candles={candles} revealed={revealed} width={680} height={h - 20} />
    </div>
  );

  // ===== VARIANT: classic (doc wireframe) =====
  if (variant === "classic") {
    return (
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "18px 22px 30px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14, flexWrap: "wrap", gap: 12 }}>
          <InstrumentHead name="贵州茅台" candle={candle} prevClose={prevClose} blind={blind} big />
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}><PlayCtl /><Countdown remaining={remaining} total={240} /></div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 16, alignItems: "start" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {chartCard(360)}
            <Card padding="16px"><HUD pf={pf} /></Card>
            <Card padding="16px"><TradeActions qty={qty} setQty={setQty} pct={pctSel} setPct={setPctSel} onLoan={onLoan} /></Card>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Card padding="12px"><Leaderboard rows={rows} /></Card>
            <Card padding="14px"><PropBar items={myProps} /></Card>
          </div>
        </div>
      </div>
    );
  }

  // ===== VARIANT: focus (big actions) =====
  if (variant === "focus") {
    return (
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "18px 22px 30px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <Badge tone="cn" dot>大 A · 贵州茅台</Badge>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}><PlayCtl /><Countdown remaining={remaining} total={240} size="sm" /></div>
        </div>
        <div style={{ textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: 6, margin: "6px 0 16px" }}>
          <PriceTag price={candle.c} changePct={((candle.c - prevClose) / prevClose) * 100} size="lg" />
          <span style={{ fontSize: "var(--text-sm)", color: "var(--text-tertiary)" }}>净值 <b style={{ color: net >= 100000 ? "var(--price-up)" : "var(--price-down)", fontFamily: "var(--font-mono)" }}>{window.yuan(net)}</b> · {window.pct((net - 100000) / 1000)}</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 16, alignItems: "start" }}>
          {chartCard(330)}
          <Card padding="12px"><Leaderboard rows={rows} /></Card>
        </div>
        {/* sticky bottom action bar */}
        <div style={{ marginTop: 16, background: "var(--surface-card)", border: "1px solid var(--border-subtle)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-md)", padding: 16, display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
          <HUD pf={pf} compact />
          <div style={{ flex: 1 }} />
          <NumberStepper value={qty} step={10} unit="股" onChange={setQty} />
          <QuickAmount value={pctSel} onChange={setPctSel} />
          <Button variant="up" size="lg" iconLeft={<window.Icon name="trending-up" size={18} />}>买入</Button>
          <Button variant="down" size="lg" iconLeft={<window.Icon name="trending-down" size={18} />}>做空</Button>
          <Button variant="ghost" size="lg" onClick={onLoan} style={{ border: "1px solid var(--border-default)" }}>贷款</Button>
        </div>
      </div>
    );
  }

  // ===== VARIANT: dense (data-heavy) =====
  return (
    <div style={{ maxWidth: 1280, margin: "0 auto", padding: "14px 18px 26px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12, gap: 12, flexWrap: "wrap" }}>
        <InstrumentHead name="贵州茅台" candle={candle} prevClose={prevClose} blind={blind} />
        <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
          <HUD pf={pf} compact />
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}><PlayCtl /><Countdown remaining={remaining} total={240} size="sm" /></div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "288px 1fr 290px", gap: 12, alignItems: "start" }}>
        <Card padding="12px"><Leaderboard rows={rows} compact /></Card>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {chartCard(316)}
          <Card padding="12px">
            <PropBar items={myProps} />
          </Card>
        </div>
        <Card padding="14px"><TradeActions qty={qty} setQty={setQty} pct={pctSel} setPct={setPctSel} onLoan={onLoan} compact /></Card>
      </div>
    </div>
  );
}
window.Trading = Trading;
